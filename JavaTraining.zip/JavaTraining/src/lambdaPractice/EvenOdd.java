package lambdaPractice;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class EvenOdd {

	public static void print(int a) {
    	System.out.println("int: " + a);
	}
 	public static void print(Integer a) {
    	System.out.println("Integer: " + a);
	}
 
	public static void main(String[] args) {
    	int a = 5;
    	Integer b = 10;
    	print(a);
    	print(b);
	}
	}


package lambdaPractice;

import java.util.Arrays;
import java.util.List;

public class UpperCase {

	public static void main(String[] args) {
		 List<String> stringList = Arrays.asList("Red", "Green", "Blue", "PINK");
		 stringList.replaceAll(str-> str.toLowerCase());
		// stringList.forEach(str-> System.out.println(str));
		 stringList.forEach(System.out::println);
		 
		 
	}
}

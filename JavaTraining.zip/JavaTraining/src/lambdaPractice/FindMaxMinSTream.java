package lambdaPractice;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class FindMaxMinSTream {
	
	public static void main(String[] args) {
		List<Integer> intNum = new ArrayList<>();
		
		intNum.add(2);
		intNum.add(4);
		intNum.add(7);
		intNum.add(5);
		intNum.add(90);
		intNum.add(22);
		intNum.add(72);
		intNum.add(65);
		
		int max = intNum.stream().max(Comparator.comparing(Integer::valueOf)).get();
		intNum.stream().max(Comparator.comparing(Integer::valueOf)).get();
		int max1= intNum.stream().max((n1,n2)-> n1>n2?1:-1).get();
		int min1= intNum.stream().min(Comparator.comparing(Integer::valueOf)).get();
		System.out.println(max);
		System.out.println(max1);
		System.out.println(min1);
		System.out.println("***************");
		
		
		int max2 =intNum.stream().max(Comparator.comparing(Integer::valueOf)).get();
		int min= intNum.stream().min(Comparator.comparing(Integer::valueOf)).get();
		int max3= intNum.stream().max(Integer::compare).get();
		System.out.println(max);
		System.out.println(min);
		System.out.println(max3);
		Optional<Integer> maxNum = intNum.stream().max((a, b) -> a - b);
		System.out.println(maxNum);
		
		int countList= (int) intNum.stream().count();
		System.out.println(countList);
	}

}

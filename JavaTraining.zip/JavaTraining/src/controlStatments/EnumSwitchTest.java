package controlStatments;

public class EnumSwitchTest {
	
	public enum Day{Sun, Mon, Tue, Wed, Thurs, Fri, Sat};
	
	Day[] dayToday= Day.values();
	
	public static void main(String[] args) {
		EnumSwitchTest est= new EnumSwitchTest();
		est.weekDays(Day.Thurs);
	}
	
	public void weekDays(Day day) {
//		for(Day dayNow: dayToday){
			switch (day) {
			
			case Sun: System.out.println(day);
			break;
			
			case Mon: System.out.println(day);
			break;
			
			case Tue: System.out.println(day);
			break;
			
			case Wed: System.out.println(day);
			break;
			
			case Thurs: System.out.println(day);
			break;
			
			case Fri: System.out.println(day);
			break;
			
			case Sat: System.out.println(day);
			break;
			
			}
	//	}
	}
	

}

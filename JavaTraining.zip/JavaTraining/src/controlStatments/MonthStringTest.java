package controlStatments;

public class MonthStringTest {
	
	int month = 7;
	String strMonth = "";

	public static void main(String[] args) {
		MonthStringTest mst =new MonthStringTest();
		
		mst.printMonth(10);
	}
	
	public void printMonth(int month) {
		
		switch(month) {
		
		case 1: strMonth = "1-Jan";
		break;
		case 2: strMonth = "2-Feb";
		break;
		case 3: strMonth = "3-March";
		break;
		case 4: strMonth = "4-April";
		break;
		case 5: strMonth = "5-May";
		break;
		case 6: strMonth = "6-June";
		break;
		case 7: strMonth = "7-July";
		break;
		case 8: strMonth = "8-Aug";
		break;
		case 9: strMonth = "9-Sep";
		break;
		case 10: {
			strMonth = "10-Oct";
		}
		break;
		case 11: strMonth = "11-Nov";
		break;
		case 12: strMonth = "12-Dec";
		break;
		}
		
		System.out.println(strMonth);
	}

}

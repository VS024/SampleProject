package controlStatments;

public class SwitchTest {

	public static void main(String[] args) {

		int num= 20;
		switch(num) {
		case 10: 
			System.out.println("current number is"+ 10);
			break;
		case 60:
			System.out.println("current number is"+ num);
			break;
		case 30:
			System.out.println("current number is"+ 30);
			break;
		case 40:
			System.out.println("current number is"+ 40);
			break;
		}

	}

}

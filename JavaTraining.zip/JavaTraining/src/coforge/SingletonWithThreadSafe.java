package coforge;

public final class SingletonWithThreadSafe {

	private SingletonWithThreadSafe swtsObj;
	
	public SingletonWithThreadSafe() {
		System.out.println(swtsObj);
	}
	
	public synchronized SingletonWithThreadSafe  getInstance(SingletonWithThreadSafe swtsObj) {
		
		if(swtsObj==null) {
		return	swtsObj= new SingletonWithThreadSafe();
		}
		else {
			return swtsObj;
		}
		
	}
	
}

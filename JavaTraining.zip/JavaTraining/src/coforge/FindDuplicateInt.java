package coforge;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class FindDuplicateInt {

	public static void main(String[] args) {
		//1, 2, 2, 3, 4, 5
		//1,2,3,4,5
	
//		HashMap<Integer, Integer> map= new HashMap<>();
//		map.put(1, 1);
//		map.put(2, 2);
//		map.put(3, 2);
//		map.put(4, 3);
//		map.put(5, 4);
//		map.put(6, 5);
//		
		List<Integer> list = Arrays.asList(1, 2, 2, 3, 4,2, 5,5);
		
		for(int i=0; i<list.size(); i++) {
			
			for(int j=i+1; j<list.size(); j++) {
				if(list.get(i)== list.get(j)) {
					System.out.println(list.get(i) + "Duplicate Element");
				}
			}
		}
		
		list.stream().collect(Collectors.toSet());
		
		
		System.out.println(list.stream().collect(Collectors.toSet()));
		
	}
}

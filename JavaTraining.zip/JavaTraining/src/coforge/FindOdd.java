package coforge;

interface PerformTask{
	
	boolean chackOdd(int n);
}
public class FindOdd {
	
	public static void main(String[] args) {
		
		int num=7;
		
		isOdd(num);
		System.out.println();
	}

	static PerformTask isOdd(int num) {
		return (number)-> (number%2)!=0?true:false; 
		
	}
	

}

package coforge;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RemoveCharsAddNum {

	public static void main(String[] args) {
//		Remove unwanted chars Given an array [“123f”, “1dsa12”, “1212ds”, “65fd”, “sadfa”, “asdasd”]
//				Each item can contain 0-9, a-z, A-Z where a-z, A-Z characters are unwanted
//				Sum of all the numbers after removing all the unwanted characters 123+112+1212+65
		
		List<String> mixedStr= Arrays.asList("123f", "1dsa12", "1212ds", "65fd", "sadfa", "asdasd");
		List<String> addInteger= new ArrayList<>();
		Integer sum=0;
	try {
		for(String str:mixedStr) {
			str=str.replaceAll("[^0-9]", "");
			str=str.trim();
			//System.out.println(str);
			sum=sum+ Integer.valueOf(str);
			
			System.out.println(sum);
		}
	}catch(Exception ex) {
		
	}
	}
}

package streamJava8Test;

import java.util.Arrays;

public class ParallelArraySorting {

	public static void main(String[] args) {
		int[] arr= {5,6,3,8,4,22,12,42};
		
		for(int num:arr) {
			System.out.println(num+ " ");
		}
		Arrays.parallelSort(arr);
		for(int num:arr) {
			System.out.println(num);
		}
	}
}

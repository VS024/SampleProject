package streamJava8Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

class Employee {
	 
    // member variables
    private String name;
    private String department;
    
	public Employee(String name, String department) {
		super();
		this.name = name;
		this.department = department;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
    
}
public class GroupingByTest {

	public static void main(String[] args) {
		List<Employee> employees = Arrays.asList(
				new Employee("Pup", "IT"),
				new Employee("Pigeon", "HR"),
                new Employee("Punter", "IT"),
                new Employee("Gilly", "HR"),
                new Employee("Haydo", "IT"));
		
//		employees.stream().collect(Collectors.groupingBy(Employee::getName));
		Map<String, List<Employee>> employeeListByDepartment=
				employees.stream().collect(Collectors.groupingBy(Employee::getDepartment));
		System.out.println(employeeListByDepartment);
		for (Map.Entry<String, List<Employee>> entry : employeeListByDepartment.entrySet()) {
			System.out.println(entry.getKey()+ " "+ entry.getValue());
		}
		 employees.stream().collect(Collectors.groupingBy(e->e.getDepartment()));
		
	}
}

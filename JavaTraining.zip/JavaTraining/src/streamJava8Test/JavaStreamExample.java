package streamJava8Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Product{
	int id;
	String name;
	float price;
	public Product(int id, String name, float price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
	
}
public class JavaStreamExample {

public static void main(String[] args) {
	List<Product> p1= new ArrayList<Product>();
	p1.add(new Product(1, "Dell", 2000f));
	p1.add(new Product(2, "Keyboard", 200f));
	p1.add(new Product(3,"Lenevo Laptop",28000f));  
    p1.add(new Product(4,"Sony Laptop",28500f));  
    p1.add(new Product(5,"Apple Laptop",90000f));  
    
    List<Float> p1Stream= p1.stream().filter(n->n.price>2000f)
    		.map(n->n.price)
    		.collect(Collectors.toList());
    System.out.println(p1Stream);
    
   Stream.iterate(20, element-> element+1)
   .filter(element ->element%5==0)
   .limit(4)
   .forEach(System.out::println);
   
 Product productA = p1.stream().max((product1, product2)->product1.price > product2.price ? 1: -1).get();   
   
 // Product p2= p1.stream().max((prd1, prd2)-> prd1.price > prd2?1:-1).get();
}
}

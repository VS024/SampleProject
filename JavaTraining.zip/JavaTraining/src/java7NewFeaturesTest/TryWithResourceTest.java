package java7NewFeaturesTest;

import java.io.FileOutputStream;

public class TryWithResourceTest {

	public static void main(String[] args) {
		
		try(FileOutputStream fos= new FileOutputStream("/JavaTraining/src/abc.txt")){
			
			String msg= "Inside try with resources";
			byte byteArray[]= msg.getBytes();
			fos.write(byteArray);
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
}

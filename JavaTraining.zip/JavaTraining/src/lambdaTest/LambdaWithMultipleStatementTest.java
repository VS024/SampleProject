package lambdaTest;

interface Sayable3{
	public String say(String message);
}
public class LambdaWithMultipleStatementTest {
	public static void main(String[] args) {
		Sayable3 s1=(message)->{
			String str1= "I am satement 1.";
			String str2= str1 + message;
			return str2;
			
		};
		System.out.println(s1.say(" : hello java"));
	}
}

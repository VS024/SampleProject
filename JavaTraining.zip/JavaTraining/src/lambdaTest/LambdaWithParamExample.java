package lambdaTest;

interface Sayable2{
	String say(String name);
}
public class LambdaWithParamExample {

	public static void main(String[] args) {
		Sayable2 s2= (name)->{
			return "Say hello to : " + name;
		};
		System.out.println(s2.say("Java"));
	}
}

package lambdaTest;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

class Product2{
    int id;  
    String name;  
    float price;  
    public Product2(int id, String name, float price) {  
        this.id = id;  
        this.name = name;  
        this.price = price;  
    }  
}
public class CollectionFilterWithLambda {
	public static void main(String[] args) {
		List<Product2> list = new ArrayList<>();
		
		list.add(new Product2(1, "Samsung", 17000f));
		list.add(new Product2(3,"Iphone 6S",1000f));  
        list.add(new Product2(2,"Sony Xperia",25000f));  
        list.add(new Product2(4,"Nokia Lumia",1500f));  
        list.add(new Product2(5,"Redmi4 ",26000f));  
        list.add(new Product2(6,"Lenevo Vibe",19000f));  
        
        Stream<Product2> fiteredData= list.stream().filter(p->p.price>2000f);
        
        Stream<Product2> filter2 =list.stream().filter(r->r.name.startsWith("S"));
        fiteredData.forEach(

        		n-> System.out.println(n.id + " "+ n.name +" "+ n.price));
        filter2.forEach(
        		m->System.out.println(m.id+" "+ m.name + " "+ m.price));
        
	}

}

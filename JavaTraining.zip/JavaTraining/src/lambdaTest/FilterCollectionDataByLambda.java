package lambdaTest;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

class Product8{  
    int id;  
    String name;  
    float price;  
    public Product8(int id, String name, float price) {  
        super();  
        this.id = id;  
        this.name = name;  
        this.price = price;  
    }  
}  
public class FilterCollectionDataByLambda {

	public static void main(String[] args) {

		List<Product8> list=new ArrayList<Product8>();  
        list.add(new Product8(1,"Samsung A5",17000f));  
        list.add(new Product8(3,"Iphone 6S",65000f));  
        list.add(new Product8(2,"Sony Xperia",25000f));  
        list.add(new Product8(4,"Nokia Lumia",15000f));  
        list.add(new Product8(5,"Redmi4 ",26000f));  
        list.add(new Product8(6,"Lenevo Vibe",19000f)); 
        
        Stream<Product8> filtered_data =  list.stream().filter(p->p.price>15000);
        filtered_data.forEach(n->System.out.println(n.name + " " +n.price));
	    
	}
}

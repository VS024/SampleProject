package lambdaTest;

interface Addable{
	int add(int a, int b);
}
public class LambdaMultipleParamsTest {
	public static void main(String[] args) {
		Addable ad1= (a,b)->a+b;//lambda w/o return
		System.out.println(ad1.add(2, 4));
		
		Addable ad2= (a,b)->{
			return a+b;// lambda with return
		};
		System.out.println(ad2.add(6, 10));
	}
}

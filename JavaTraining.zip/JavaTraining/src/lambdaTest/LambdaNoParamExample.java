package lambdaTest;
interface Sayable{
	String say();
}

public class LambdaNoParamExample {
	public static void main(String[] args) {
		Sayable s1= ()->{
			return "Say hi to no param Lambda Expression";
	};
	System.out.println(s1.say());
	
}
}
package lambdaTest;

interface Drawing2{
	public void draw();
	//public void diplay(); //The target type of this expression must be a functional interface
}
public class LambdaExpressionExample2 {

	
	public static void main(String[] args) {
		int width=5;
		Drawing2 d2= ()-> {
			System.out.println("Drawing"+ width);
	};
	d2.draw();
	}
}

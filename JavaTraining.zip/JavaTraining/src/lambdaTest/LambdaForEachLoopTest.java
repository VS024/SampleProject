package lambdaTest;

import java.util.ArrayList;
import java.util.List;

public class LambdaForEachLoopTest {
	public static void main(String[] args) {
		List<String> nameList=  new ArrayList<>();
		nameList.add("Sita");
		nameList.add("Ravi");
		nameList.add("Damini");
		nameList.add("Rohit");
		
		nameList.forEach(
				(n)-> System.out.println(n));
	}

}

package lambdaTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Product{
	int prdId;
	String prdName;
	float prdPrice;
	public Product(int prdId, String prdName, float prdPrice) {
		this.prdId = prdId;
		this.prdName = prdName;
		this.prdPrice = prdPrice;
	}
	
}
public class ComparatotWithLambda {

	public static void main(String[] args) {

		List<Product> list= new ArrayList<Product>();
		
		list.add(new Product(1, "HP", 30000));
		list.add(new Product(2, "Dell", 50000));
		list.add(new Product(3,  "Lenovo", 25000));

		
		list.forEach(
				n-> System.out.println(n.prdId + " " +n.prdName+ " " + n.prdPrice));
		Collections.sort(list, (p1,p2)->{
			return p1.prdName.compareTo(p2.prdName);
		});
		
		System.out.println("After sorting");
		list.forEach(
				n-> System.out.println(n.prdId + " " +n.prdName+ " " + n.prdPrice));
	}
	

}


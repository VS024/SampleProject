package objCopyTest;

public class CopyObjByConstructorTest {
//copy value of an obj into other obj using constructor
	int id;
	String name;
	String collegeName = "IST";
	CopyObjByConstructorTest(int id, String name){
		this.id=id;
		this.name=name;
	}
	CopyObjByConstructorTest(CopyObjByConstructorTest cobyObj){
		this.id=cobyObj.id;
		this.name= cobyObj.name;
	}
	public void display() {
		System.out.println(id+ " " + name + " "+ collegeName);
	}
	public static void main(String[] args) {
		
		CopyObjByConstructorTest orgObj= new CopyObjByConstructorTest(1, "Sita");
		CopyObjByConstructorTest copyObj= new CopyObjByConstructorTest(orgObj);//1:by passing obj as an argument to other object
		CopyObjByConstructorTest copyObj2= orgObj;
		orgObj.display();
		copyObj.display();
		copyObj2.display();//2: copy the values of one object into another by assigning the objects values to another object
		
	}
}

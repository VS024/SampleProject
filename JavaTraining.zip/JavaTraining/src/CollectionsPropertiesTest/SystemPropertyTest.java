package CollectionsPropertiesTest;

import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class SystemPropertyTest {

		public static void main(String[] args) {
			Properties prp= System.getProperties();
			//Set pset= prp.entrySet();
			
			for(Map.Entry prpset: prp.entrySet()) {
				System.out.println(prpset.getKey() + " " +prpset.getValue());
			}
		}
}
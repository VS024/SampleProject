package hashSetTest;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class COnvertSetToArray {

	public static void main(String[] args) {
		Set<String> strSet= new HashSet<>();
		
		strSet.add("A");
		strSet.add("E");
		strSet.add("I");
		strSet.add("O");
		strSet.add("U");
		
		String[] strArry= new String[strSet.size()];
		
		strSet.toArray(strArry);
		for(String eachStr: strArry)
		System.out.println(eachStr);
	}
}

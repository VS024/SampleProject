package methodRefferenceJava8;

interface Messagable{
	Message getMesage(String msg);
	default void getMesage1() {
		System.out.println("defaul Method in interface");
	}
	
}
class Message{
	Message(){
		System.out.println("inside no arg constructor");
	}
	Message(String msg){
		System.out.println(msg);
	}
}
public class ConstructorReferenceTest {
	public static void main(String[] args) {
		Messagable hello= Message::new;
		hello.getMesage("Printing from constructor call");
		hello.getMesage1();
		
	}

}

package methodRefferenceJava8;

interface Sayable4{
	void say();
}
public class StaticMethodRefferenceTest {  
	//static
    public static void saySomething(){  
        System.out.println("Hello, this is static method.");  
    }  
    public static void main(String[] args) {  
        // Referring static method  
        Sayable4 sayable = StaticMethodRefferenceTest::saySomething;  
        // Calling interface method  
        sayable.say();  

    }  

}

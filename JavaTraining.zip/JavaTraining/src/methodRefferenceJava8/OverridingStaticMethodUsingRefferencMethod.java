package methodRefferenceJava8;

import java.util.function.BiFunction;

class Arithmatic5{
	public static int add(int a, int b) {
		return a+b;
	}
	public static float add(int x, float y) {
		return x+y;
	}
	public static float add(float i, float j) {
		return i+j;
	}
}
public class OverridingStaticMethodUsingRefferencMethod {
 public static void main(String[] args) {
	 BiFunction<Integer, Integer, Integer> ab1= Arithmatic5::add;
	 BiFunction<Integer, Float, Float> ab2= Arithmatic5::add;
	 BiFunction<Integer, Float, Float> ab3= Arithmatic5::add;
	 
	 System.out.println(ab1.apply(2, 4));
	 System.out.println(ab2.apply(4,  65f));
	 System.out.println(ab3.apply(72, 98f));
}
}

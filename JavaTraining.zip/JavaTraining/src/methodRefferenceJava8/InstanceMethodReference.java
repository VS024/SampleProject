package methodRefferenceJava8;

interface Sayable6{
 void say();	
}
public class InstanceMethodReference {
	public void saySomething() {
		System.out.println("Hello , this is instance Method");
	}
	public static void main(String[] args) {
		InstanceMethodReference imr= new InstanceMethodReference();
		Sayable6 s6= imr::saySomething;
		s6.say();
	}
}

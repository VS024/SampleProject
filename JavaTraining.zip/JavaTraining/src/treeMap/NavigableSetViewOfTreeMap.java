package treeMap;

import java.util.SortedMap;
import java.util.TreeMap;

public class NavigableSetViewOfTreeMap {

	public static void main(String[] args) {
		  TreeMap < Integer, String > tree_map1 = new TreeMap < Integer, String > ();

		  // Put elements to the map 
		  tree_map1.put(10, "Red");
		  tree_map1.put(20, "Green");
		  tree_map1.put(40, "Black");
		  tree_map1.put(50, "White");
		  tree_map1.put(60, "Pink");
		  
		  System.out.println(tree_map1);
		  System.out.println(tree_map1.navigableKeySet());
		  SortedMap<Integer, String> tree_map2 = new TreeMap < Integer, String > ();
		  tree_map2= tree_map1.subMap(20, 60);
		  
		System.out.println(tree_map2);
		
	}
}

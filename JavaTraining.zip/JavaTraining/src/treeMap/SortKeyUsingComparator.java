package treeMap;

import java.util.Comparator;
import java.util.TreeMap;

public class SortKeyUsingComparator {

	public static void main(String[] args) {
		TreeMap<String, String> tree_map1 = new TreeMap<>(new Sort_treeMap());
	//	TreeMap<String, String> tree_map1 = new TreeMap<>();
		 tree_map1.put("C2", "Red");
		  tree_map1.put("C4", "Green");
		  tree_map1.put("C3", "Black");
		  tree_map1.put("C1", "White"); 
		  
		  System.out.println(tree_map1);
	}
}

class Sort_treeMap implements Comparator<String>{


	@Override
	public int compare(String s1, String s2) {
		return s1.compareTo(s2);
	}
}

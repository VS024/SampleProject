package treeMap;

import java.util.TreeMap;

public class TreeMapTest {
	public static void main(String[] args) {
		TreeMap<Integer, String> trMap= new TreeMap<>();
		trMap.put(1, "DAV");
		trMap.put(2, "KV");
		trMap.put(4, "St. Thomas");
		trMap.put(3, "Army");
		
		
		System.out.println(trMap);
	}
}

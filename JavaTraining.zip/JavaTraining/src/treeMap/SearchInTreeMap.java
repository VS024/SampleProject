package treeMap;

import java.util.TreeMap;

public class SearchInTreeMap {

	public static void main(String[] args) {
		TreeMap<Integer, String> trMap= new TreeMap<>();
		trMap.put(1, "DAV");
		trMap.put(2, "KV");
		trMap.put(4, "St. Thomas");
		trMap.put(3, "Army");
		System.out.println(trMap.containsKey(3));
		System.out.println(trMap.containsValue("KVD"));
		System.out.println(trMap.get(2));
		System.out.println(trMap.keySet());
		trMap.clear();
		System.out.println(trMap);
	}
}

package treeMap;

import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapTest {

	public static void main(String[] args) {
		ConcurrentHashMap<Integer,String> cncrtMap= new ConcurrentHashMap<>();
		cncrtMap.put(8, "Third");
		cncrtMap.put(6, "Second");
		cncrtMap.put(3, "First");
		
		Iterator<ConcurrentHashMap.Entry<Integer, String>> chmapItr= cncrtMap.entrySet().iterator();
		
		Iterator itr= cncrtMap.entrySet().iterator();
//		while(chmapItr.hasNext()) {
//			System.out.println(chmapItr.next());
//		}
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}

package collectionTest;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Properties;

public class PropertyFileTest {

	public static void main(String[] args) throws Exception{
		FileReader reader= new FileReader("test.properties");
		Properties p=new Properties();  
		
	    p.load(reader);  
		System.out.println(p.propertyNames());
		System.out.println(p.getProperty("user"));
		System.out.println(p.getProperty("password"));
		
	}
}

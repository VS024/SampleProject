package collectionTest;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class SortingUsingLambda {

	public static void main(String[] args) {
		List<String> fruitlist= Arrays.asList("banana", "apple", "orange", "kiwi");
//		fruitlist.sort((s1,s2)-> s1.compareTo(s2));
//		System.out.println(fruitlist);
		
		Collections.sort(fruitlist);
		System.out.println(fruitlist);
		
	}
}

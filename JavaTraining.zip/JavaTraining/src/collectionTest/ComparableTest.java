package collectionTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Student2 implements Comparable<Student2>{
	
	int rollNo;
	String name;
	int age;
	public Student2(int rollNo, String name, int age) {
		this.rollNo = rollNo;
		this.name = name;
		this.age = age;
	}
//	//sorting
//	public int compareTo(Student2 std) {
//		
//		if(age==std.age)  
//			return 0;
//		
//		else if(age>std.age)
//			return 1;
//		
//		else 
//			return -1;
//	}

	//sorting in reverse
	public int compareTo(Student2 std3) {
		if(age== std3.age)
			return 0;
		else if(age>std3.age)
			return -1;
		else return 1;
	}
	
}
public class ComparableTest {
	public static void main(String[] args) {
		ArrayList<Student2> al=new ArrayList<Student2>();  
		al.add(new Student2(101,"Vijay",23));  
		al.add(new Student2(106,"Ajay",27));  
		al.add(new Student2(105,"Jai",21));  
		Collections.sort(al);
		for(Student2 std2:al) {
			
			System.out.println(std2.rollNo + " " + std2.name + " " + std2.age);
		}
	}
}

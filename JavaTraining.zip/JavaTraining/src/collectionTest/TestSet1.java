package collectionTest;

import java.util.HashSet;
import java.util.Objects;

class Animal{
	
	int i=12;
	public Animal() {
		i=13;
	}

	@Override
	public int hashCode() {
		return Objects.hash(i);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Animal other = (Animal) obj;
		return i == other.i;
	}

	public String toString() {
		return "Animal" + i;
	}
}
public class TestSet1 {
	public static void main(String[] args) {
		HashSet<String> set= new HashSet();
		HashSet<Animal> setAnml= new HashSet();
		setAnml.add(new Animal());
		setAnml.add(new Animal());
		for(Animal a:setAnml) {
			System.out.println(a);
		}
		//if we dont override hashcode and equals then duplicate objects will get added
		set.add("A");
		set.add("A");
		for(String a:set) {
			System.out.println(a);
		}
	}
}

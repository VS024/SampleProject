package collectionTest;

import java.util.EnumMap;
import java.util.Map;

public class EnumMapTest {
	enum Days{
		SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
	};
	
	public static void main(String[] args) {
		EnumMap<Days, Integer> enumMap= new EnumMap<Days, Integer>(Days.class);
		enumMap.put(Days.SUNDAY, 1);
		enumMap.put(Days.MONDAY, 2);
		enumMap.put(Days.TUESDAY, 3);
		enumMap.put(Days.WEDNESDAY, 4);
		
		for(Map.Entry m:enumMap.entrySet()){
			System.out.println(m.getKey()+" "+m.getValue());    
			
		}
	}
}

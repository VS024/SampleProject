package collectionTest;

import java.util.LinkedHashMap;
import java.util.Map;

class Book1{
	int id;    
	String name,author,publisher;    
	int quantity;
	public Book1(int id, String name, String author, String publisher, int quantity) {
		
		this.id = id;
		this.name = name;
		this.author = author;
		this.publisher = publisher;
		this.quantity = quantity;
	}  
	
	
}
public class LinkedHashMapValuesAsObjectTest {
	public static void main(String[] args) {
		Map<Integer, Book> bookMap= new LinkedHashMap<>();
		
		bookMap.put(1,  (new Book(1, "Geeta", "Tulsi", "Tulsi",10)));
		bookMap.put(2,  (new Book(2, "Geeta", "Tulsi", "Tulsi",10)));
		bookMap.put(3,  (new Book(3, "Geeta", "Tulsi", "Tulsi",10)));
		bookMap.put(4,  (new Book(4, "Geeta", "Tulsi", "Tulsi",10)));
		bookMap.put(5,  (new Book(5, "Geeta", "Tulsi", "Tulsi",10)));
		
		bookMap.entrySet().forEach(System.out::println);
		
		for(Map.Entry<Integer, Book> mapentry:bookMap.entrySet()) {
			int key =mapentry.getKey();
			Book value= mapentry.getValue();
			
			System.out.println(key + ": " +value.id+ "," +value.name+ " "+ value.author+ " " +value.publisher+" " + value.quantity);
			
		}
		
 	}
}

package collectionTest;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapExample1 {

	public static void main(String[] args) {
		Map<String, String> hmap= new HashMap<>();
		hmap.put("A", "K V");
		hmap.put("B",  "Army");
		hmap.put("C",  "DAV");
		hmap.put("D", "St. Javier");
		hmap.put( "D", "St. Marium");
		hmap.put("E", null);
		hmap.put("F", null);
		hmap.put(null, "Mt. Litera");
		hmap.put( "D", "St. Loyala");
		//sorting by key/value in reverse order
		//hmap.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.reverseOrder())).forEach(System.out::println);
		//Iterating Map element
		hmap.entrySet().forEach(System.out::println);
		System.out.println("*********************************");
//		for(Map.Entry m:hmap.entrySet()) {
//			System.out.println(m.getKey()+ ": " + m.getValue());
//			
//		}
		//key as null
		HashMap<Integer,String> map2=new HashMap<Integer,String>();//Creating HashMap  
		   map2.put(1,"Mango");  //Put elements in Map
		   map2.put(2,"Apple");  
		   map2.put(3,"Banana"); 
		   map2.put(null,"Grapes");
		   map2.put(null,"Peas");
		   map2.entrySet().forEach(System.out::println);
		 //  Map.Entry<Integer,String> entry= (Entry<Integer, String>) map2.entrySet();
		   Set<Integer> set =new HashSet<>(map2.keySet());
		   System.out.println(set);
	}
}

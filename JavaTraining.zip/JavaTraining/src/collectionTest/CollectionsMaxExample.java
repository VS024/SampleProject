package collectionTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CollectionsMaxExample {

	public static void main(String[] args) {
		List<Integer> list= new ArrayList<>();
		
		list.add(104);
		list.add(298);
		list.add(23);
		list.add(54);
		
		//list.stream().max(p1,p2-> p1>p2?1:-1);
		Collections.max(list);
		System.out.println("Max in the list : "+ Collections.max(list));
		System.out.println("Max in the list : "+ Collections.min(list));
	}
}

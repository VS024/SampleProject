package collectionTest;

import java.util.Arrays;
import java.util.List;

class Person6{
	
	private String name;  
    private int age;  
    public Person6(String name, int age) {  
        this.name = name;  
        this.age = age;  
    }  
    public String getName() {  
        return name;  
    }  
    public int getAge() {  
        return age;  
    }  
    @Override  
    public String toString() {  
        return name + " (" + age + ")";  
    }  

    public int compare(Integer a1, Integer a2) {
    	if(a1==a2)
    		return 0;
    	else if(a1>a2)
    		return 1;
    	else
    		return -1;
    }
}
public class CustomObjectSortingUsingLambda {
	public static void main(String[] args) {
		List<Person6> prsnList= Arrays.asList(new Person6("Ram", 22),  
                new Person6("Ravi", 23),  
                new Person6("Bobby", 31),  
                new Person6("Musk", 28) );
		
	//	prsnList.sort((s1,s2)->s1.getName().compareTo(s2.getName()));
		prsnList.sort((s3,s4)-> s4.compare(s3.getAge(), s4.getAge()));
		System.out.println(prsnList);
		System.out.println("*************************************");
		
	//	prsnList.sort(null);
		
	}
}

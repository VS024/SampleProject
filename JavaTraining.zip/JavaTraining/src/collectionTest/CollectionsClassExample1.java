package collectionTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CollectionsClassExample1 {

	public static void main(String[] args) {
		List<String> list= new ArrayList<>();
		
		list.add("Collection");
		list.add("class");
		list.add("is");
		list.add("added");
		list.add("inside");
		list.add("java.util");
		list.add("package");
		
		Collections.addAll(list);
		System.out.println(list);
		String[] strArr= {"in ", "Java"};
		Collections.addAll(list, strArr);
		System.out.println(list);
	}
}

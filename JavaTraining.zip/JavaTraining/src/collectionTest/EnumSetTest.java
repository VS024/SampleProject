package collectionTest;

import java.util.EnumSet;
import java.util.Set;

enum days{
	SUNDAY,MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY;
}
public class EnumSetTest {

	public static void main(String[] args) {
		Set<days> dset= EnumSet.of(days.TUESDAY, days.WEDNESDAY);
		dset.forEach(System.out::println);
	}
}

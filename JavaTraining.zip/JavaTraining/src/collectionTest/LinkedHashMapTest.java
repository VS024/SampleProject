package collectionTest;

import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapTest {

	public static void main(String[] args) {
		
		Map<Integer, String> lhMap= new LinkedHashMap<>();
		
		lhMap.put(1, "Bangalore");
		lhMap.put(2, "Chennai");
		lhMap.put(3, "Delhi");
		lhMap.put(4, "Ranchi");
		lhMap.put(5, "Mumbai");
		lhMap.entrySet().stream().forEach(System.out::println);
		lhMap.entrySet().stream().forEach(System.out::println);
		for(Map.Entry map: lhMap.entrySet()) {
			System.out.println(map.getKey()+ ": "+ map.getValue());
		}
		
	}
}

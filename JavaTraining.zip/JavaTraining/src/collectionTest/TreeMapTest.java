package collectionTest;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapTest {
	public static void main(String[] args) {
		//TreeMap order Map in natural order of the key
		Map<Integer, String> tmap= new TreeMap<>();
		
		tmap.put(103, "Raj");
		tmap.put(106, "Rahul");
		tmap.put(101, "Vikas");
		tmap.put(108, "Tina");
		
		System.out.println(tmap.getOrDefault(108, "Rohny"));
		System.out.println(tmap.getOrDefault(105, "Rohny"));
		tmap.entrySet().forEach(System.out::println);
	}
}

package collectionTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CollectionsSortExample2 {
	public static void main(String[] args) {
		List<String> slist= new ArrayList<>();
		
		slist.add("A");
		slist.add("D");
		slist.add("b");
		slist.add("B");
		
		Collections.sort(slist);
		System.out.println(slist);
	}
}

package collectionTest;

import java.util.EnumSet;
import java.util.Set;

enum Months{
	JANUARY, FABURARY, MARCH, APRIL,MAY,JUNE,JULY,AUGUST,SEPTEMBER,OCTOBER,NOVMBER,DECEMBER;
}
public class EnumSetTest2 {
	public static void main(String[] args) {
		Set<Months> mSet= EnumSet.allOf(Months.class);
		System.out.println("Month of Year: "+ mSet);
		
		Set<Months> nomSet = EnumSet.noneOf(Months.class);
				System.out.println("Set of no month : " + nomSet );
	}
}

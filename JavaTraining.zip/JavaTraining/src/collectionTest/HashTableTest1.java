package collectionTest;

import java.util.Hashtable;
import java.util.Map;

public class HashTableTest1 {

	public static void main(String[] args) {
		
		Hashtable<Integer, String> ht= new Hashtable<>();
		
		ht.put(1, "India");
		ht.put(2, "UK");
		ht.put(3, "UN");
		ht.put(4, "USA");
		
		ht.putIfAbsent(4, "China");
		ht.entrySet().forEach(System.out::println);
//		for(Map.Entry<Integer, String> htEntry: ht.entrySet()) {
//			int key = htEntry.getKey();
//			String value= htEntry.getValue();
//		}
	}
}

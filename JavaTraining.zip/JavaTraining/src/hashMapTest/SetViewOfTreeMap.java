package hashMapTest;

import java.util.HashMap;
import java.util.Set;

public class SetViewOfTreeMap {
	public static void main(String[] args) {
		HashMap<Integer, String> map= new HashMap<>();
		map.put(1, "DAV");
		map.put(2, "KV");
		map.put(3, "Army");
		map.put(4, "St. Thomas");
		
		Set<Integer> keySet= map.keySet();
		System.out.println(keySet);
		
		String valueSet= map.get(2);
		System.out.println(valueSet);
	}
}

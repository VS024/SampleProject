package hashMapTest;

import java.util.HashMap;
import java.util.Map;

public class ShalloWCoppyOfHashMap {

	public static void main(String[] args) {
		HashMap<Integer, String> map= new HashMap<>();
		map.put(1, "DAV");
		map.put(2, "KV");
		map.put(3, "Army");
		map.put(4, "St. Thomas");
		HashMap<Integer, String> map2= new HashMap<>();
		map2= (HashMap<Integer,String>)map.clone();
		System.out.println(map2);
		
		if(map.containsValue("FArmy")) {
			System.out.println("True");
		}
		if(map.containsKey(0)) {
			System.out.println("True");
		}
		for(Map.Entry itrMap: map2.entrySet()) {
			System.out.println(itrMap.getKey()+ ": " + itrMap.getValue());
			
		}
		
		
	}
}

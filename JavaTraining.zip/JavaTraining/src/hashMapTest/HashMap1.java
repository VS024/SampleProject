package hashMapTest;

import java.util.HashMap;
import java.util.Map;

public class HashMap1 {

	public static void main(String[] args) {
		HashMap<Integer, String> map= new HashMap<>();
		
		map.put(1, "A");
		map.put(2, "E");
		map.put(3, "I");
		map.put(4, "O");
		map.put(5, "U");
		
		HashMap<Integer, String> map2= new HashMap<>();
		System.out.println(map2.isEmpty());
		map2.putAll(map);
		map2.put(6, "Vowel");
		System.out.println(map.size());
		map.entrySet().forEach(m->System.out.println(m.getKey()+" : "+ m.getValue()));
		for(Map.Entry eachKey: map2.entrySet()) {
			
			System.out.println(eachKey.getKey()+ ": "+ eachKey.getValue());
		}
		
	}
}

package hashMapTest;

import java.util.HashMap;

public class CollectionViewOfMAp {

	public static void main(String[] args) {
		HashMap<Integer, String> map= new HashMap<>();
		map.put(3, "Army");
		map.put(1, "DAV");
		map.put(4, "St. Thomas");
		map.put(2, "KV");
		map.entrySet().forEach(m->System.out.println(m.getValue()));
		//System.out.println(map.values());
	}
}

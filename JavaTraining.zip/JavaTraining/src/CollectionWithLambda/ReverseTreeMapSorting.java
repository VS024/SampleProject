package CollectionWithLambda;

import java.util.TreeMap;
import java.util.TreeSet;

public class ReverseTreeMapSorting {

	public static void main(String[] args) {
		TreeMap<String,String> rvrMap= new TreeMap<>((str1,str2)-> str2.compareTo(str1));
		//In map sorting happens on key
		rvrMap.put("A", "Apple");
		rvrMap.put("C", "Mango");
		rvrMap.put("D", "Orange");
		rvrMap.put("F", "Banana");
		rvrMap.put("E", "Grapes");
		System.out.println(rvrMap);
	}
}

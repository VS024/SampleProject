package CollectionWithLambda;

import java.util.ArrayList;
import java.util.List;

public class IterateWithLambda {

	public static void main(String[] args) {
		List<String> list= new ArrayList<>();
		list.add("ankit");  
        list.add("mayank");  
        list.add("irfan");  
        list.add("jai"); 
        
        list.forEach(n-> System.out.println(n));
      //  list.forEach((n)-> System.out.println(n));
	}
}

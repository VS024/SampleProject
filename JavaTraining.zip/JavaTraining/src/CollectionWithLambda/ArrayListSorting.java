package CollectionWithLambda;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListSorting {

	public static void main(String[] args) {
		ArrayList<Integer> intArr= new ArrayList<>();
		intArr.add(2);
		intArr.add(3);
		intArr.add(8);
		intArr.add(12);
		intArr.add(16);
		intArr.add(21);
		intArr.add(92);
		
	Collections.sort(intArr, (a1, a2)->(a1>a2)?-1 : (a1<a2)?1 : 0);
		//Collections.sort(intArr);
		System.out.println(intArr);
	}
}

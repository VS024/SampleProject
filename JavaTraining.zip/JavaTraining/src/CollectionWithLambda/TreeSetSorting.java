package CollectionWithLambda;

import java.util.TreeSet;

public class TreeSetSorting {
	public static void main(String[] args) {
		TreeSet<Integer> trSet= new TreeSet<Integer>((o1,o2)-> (o1>o2)?1 : (o1<o2)?-1:0);
		
		trSet.add(850);
		trSet.add(235);
		trSet.add(1080);
		trSet.add(15);
		trSet.add(5);
		
		System.out.println(trSet);
	}
}

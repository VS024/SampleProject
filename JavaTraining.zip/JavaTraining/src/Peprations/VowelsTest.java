package Peprations;

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

interface PerformOperation {
  boolean check(int n);
}
class MyLogic{
	
	public static boolean checker(PerformOperation p, int num) {
		return p.check(num);
	}
	
	public PerformOperation isOdd(int number) {
		return (num) -> (num % 2 != 0);
	}
	public PerformOperation isPrime(int number) {
		return (num)-> {
			for(int i=2; i<num/2; i++) {
				if(num%i==0)
					return false;
		}
		return true;	
		};
	}
	public PerformOperation isPalindrome() {
		
		return (num)-> {
			String str= num+" ";
			String newStr= new StringBuffer(str).reverse().toString();
			return str.equals(newStr);
			
		};
	}
}
public class VowelsTest{
	public static void main(String[] args) {
		MyLogic m1= new MyLogic();
		m1.isOdd(13);
	}
}
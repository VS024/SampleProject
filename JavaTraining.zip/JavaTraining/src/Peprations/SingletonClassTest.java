package Peprations;


class SingletonClass {

	private static SingletonClass singltncls;
	
	private SingletonClass() {
		
	}
	public static SingletonClass getInstance() {
		if(singltncls == null) {
			singltncls= new SingletonClass();
		}return  singltncls;
	}
	
}
public class SingletonClassTest{
	public static void main(String[] args) {
		SingletonClass scObj= SingletonClass.getInstance();
		SingletonClass scObj1= SingletonClass.getInstance();
		SingletonClass scObj2= SingletonClass.getInstance();
		SingletonClassTest testObj= new SingletonClassTest();
		SingletonClassTest testOb2= new SingletonClassTest();
		System.out.println(scObj);
		System.out.println(scObj2);
		System.out.println(scObj1);
		System.out.println(testObj);
System.out.println(testOb2);
	}
	
}

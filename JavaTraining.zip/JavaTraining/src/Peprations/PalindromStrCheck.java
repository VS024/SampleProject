package Peprations;

public class PalindromStrCheck {

	public static void main(String[] args) {
		 String str = "geeks";
	        String str2 = "RACEcar";
	        if(isPalindrom(str)) {
	        	System.out.println("Pallindrom String");
	        }else
	        	System.out.println("Not Pallindrom");

	}
	static boolean isPalindrom(String str) {
        int i=0;
        int j= str.length()-1;
        while(i<j) {
        	if(str.charAt(i)==str.charAt(j)) 
        		return false;
        	
        	i++;
    		j--;
        }
        return true;

	}
	
}

package Peprations;

import java.util.StringJoiner;

public class ReverseString {

	public static void main(String[] args) {
		String str= "Java Training For Beginners";
		
		StringBuilder strbldr;
		String[] strArray= str.split(" ");
		 StringJoiner joinNames = new StringJoiner(" "); 
		for(String array: strArray) {
			strbldr = new StringBuilder();
			strbldr.append(array);
			strbldr.reverse().append(" ");
			joinNames.add(strbldr);
		}
		System.out.println(joinNames);
	}
}
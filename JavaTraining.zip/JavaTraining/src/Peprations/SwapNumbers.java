package Peprations;

public class SwapNumbers {

	public static void main(String[] args) {
		int i= 5,j= 8;
		i=i+j;
		j=i-j;
		i=i-j;
		System.out.println("i = " + i +"," + "j="+ j);
		
	}
}

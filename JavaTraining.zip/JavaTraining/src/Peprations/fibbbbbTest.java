package Peprations;

public class fibbbbbTest {
 
	public static void main(String[] args) {
		
		int num=9;
		findFibb(num);
	}
	
	public static void findFibb(int num) {
		int prev1 = 1;
		int prev2=0;
		int fibb;
		if(num==1) {
			System.out.println(num);
		}else 
			prev2= prev1+prev2;
		
	}
}//https://www.digitalocean.com/community/tutorials/java-programming-interview-questions

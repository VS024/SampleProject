package Peprations;

public class FibbonaciSeries {

	public static void main(String[] args) {

		//int[] countNum= {1,2,3,4,5,6}; 
		int num= 11;
	
		findFibbo(num);
	}
	public static void findFibbo(int num) {
		int prev1= 1;
		int prev2= 0;
		int fibbNum;
		for(int i=1; i<=num; i++) {
			if(i==1) {
			System.out.println(prev2);
		}
		if(i==2) {
			System.out.println(prev1);
		}
		if(i>2) {
			
				fibbNum= prev1+prev2;//1+0,0+1,1+1,1+2,2+3,3+5,5+8,
				prev1=prev2;//0,1,1,2,3,5,8
				prev2=fibbNum;//1,1,2,3,5,8,13
				System.out.print(fibbNum + " ");
			//	System.out.println(prev2+ ",");
			}
		}
	}
	
}

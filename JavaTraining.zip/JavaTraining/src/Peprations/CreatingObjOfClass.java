package Peprations;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class CreatingObjOfClass implements Cloneable{

	public static void main(String[] args) throws CloneNotSupportedException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
		CreatingObjOfClass obj1= new CreatingObjOfClass();
		CreatingObjOfClass obj2=(CreatingObjOfClass) obj1.clone();
		
		CreatingObjOfClass obj3= CreatingObjOfClass.class.newInstance();
		Constructor<CreatingObjOfClass> obj =CreatingObjOfClass.class.getConstructor();  
		CreatingObjOfClass obj4= obj.newInstance();
	}
}

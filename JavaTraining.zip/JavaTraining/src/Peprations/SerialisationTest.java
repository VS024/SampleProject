package Peprations;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Student implements Serializable{
	
	int id;
	String name;
	public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	 
	
}
public class SerialisationTest {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Student s1= new Student(1, "Ramesh");
		
		FileOutputStream fos= new FileOutputStream("file.text");

		ObjectOutputStream oos= new ObjectOutputStream(fos);
		oos.writeObject(s1);
		oos.flush();
		oos.close();
		
		FileInputStream fis= new FileInputStream("file.txt");
		ObjectInputStream ois= new ObjectInputStream(fis);
		Student s= (Student) ois.readObject();
		System.out.println(s.id+" "+s.name);  
		ois.close(); 
		
		
	}
	
}

package Peprations;

public class FindSubString {

	public static void main(String[] args) {
		String str= "I am Java, advance";
		String subStr= str.substring(5, 12);
		System.out.println(subStr);
	}
}

package finalKeywordTest;

class Bike2{
	final void run() {
		System.out.println("Inside PArent final method");
	}
}
//we cant override final method: CTE
public class FinalMethodTest extends Bike2{

//	void run() {//remove 'final' modifier of Bike2
//		System.out.println("Inside child Run");
//	}
	final void display() {
		System.out.println("this is a final method");
	}
	
	final void display(int i) {
		System.out.println("this is a final method" + i);
	}
	public static void main(String[] args) {
		
	}
}

package finalKeywordTest;

class FianlVriableTest{  
	final int speedlimit=90;//final variable  
	 void run(){  
	  //speedlimit=400;  //cannot assign a value to final variable speedlimit
	 }  
	 public static void main(String args[]){  
		 FianlVriableTest obj=new  FianlVriableTest();  
	 obj.run();  
	 }  
	}

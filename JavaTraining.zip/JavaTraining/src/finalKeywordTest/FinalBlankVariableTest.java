package finalKeywordTest;

public class FinalBlankVariableTest {

	final static String var; //blank final variable,  initialized in the static block only
	static{
		var= "fianleVar";
	}
	public static void main(String[] args) {
		System.out.println(var);
	}
}

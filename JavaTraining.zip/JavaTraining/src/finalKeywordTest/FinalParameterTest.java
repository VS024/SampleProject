package finalKeywordTest;

public class FinalParameterTest {

	void cube(final int x) {
	//	x= x+x+x;//If you declare any parameter as final, you cannot change the value of it
	//	x= x+2;
		System.out.println(x+2);
	}
	public static void main(String[] args) {
		FinalParameterTest fpt = new FinalParameterTest();
		fpt.cube(4);
	}
}

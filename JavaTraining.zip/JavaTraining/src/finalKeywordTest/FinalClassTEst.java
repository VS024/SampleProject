package finalKeywordTest;

final class Bike3 {

}

//public class FinalClassTEst extends Bike3 {//Final class cant be extend :CTE
//
//}
public class FinalClassTEst {//Final class cant be extend :CTE

}

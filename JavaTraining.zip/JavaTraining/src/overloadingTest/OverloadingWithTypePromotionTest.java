package overloadingTest;

public class OverloadingWithTypePromotionTest {

	  void sum(int a,long b){System.out.println("a method invoked");}  
	  void sum(long a,int b){System.out.println("b method invoked");} 
	  
	  public static void main(String[] args) {
		  OverloadingWithTypePromotionTest owtp1= new OverloadingWithTypePromotionTest();
		  OverloadingWithTypePromotionTest owtp2 = new OverloadingWithTypePromotionTest();
		//  owtp1.sum(2, 6);//The method sum(int, long) is ambiguous for the type OverloadingWithTypePromotionTest
		  //owtp2.sum(6, 8);//ava.lang.Error: Unresolved compilation problems
	}
}

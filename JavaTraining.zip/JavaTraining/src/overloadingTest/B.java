package overloadingTest;

public class B {


public static void main(String[] args) {

	boolean condition=true;
	while(condition) {
	System.out.println("loop");
	if (condition) {
	condition=false;
	}}
}

}


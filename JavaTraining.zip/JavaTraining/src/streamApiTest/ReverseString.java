package streamApiTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;
import java.util.stream.Collectors;

import problemSolving.reverseString;

public class ReverseString {

	public static void main(String[] args) {
		String str= "Geeks", nstr="";
        char ch;
       
      System.out.println("Original word: " + str );
     // System.out.println("Geeks"); //Example word
       
      for (int i=0; i<str.length(); i++)
      {
    	 // System.out.println(i);
        ch= str.charAt(i); //extracts each character
        System.out.println(ch);
        nstr= ch+nstr; //adds each character in front of the existing string
      }
      System.out.println("Reversed word: "+ nstr);
	}
	
//	public static void main(String[] args) {
//		String str= "Hello java";
////		StringBuilder revString= new StringBuilder();
////		
////		revString.append(str);
////		revString.reverse();
////		System.out.println(revString);
//		
//		char[] chrArray= str.toCharArray();
//		
//		List<Character> chrList= new ArrayList<>();
//		for(char c: chrArray) {
//			chrList.add(c);
//		}
//		
//		Collections.reverse(chrList);
//		ListIterator li = chrList.listIterator();
//        while (li.hasNext())
//            System.out.print(li.next());
//	}
}

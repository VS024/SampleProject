package streamApiTest;

import java.text.Collator;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StringUpperCase {

	public static void main(String[] args) {
		List<String> wcStr= Arrays.asList( "Wellcome!", "to", "stream", "api");
		
		List<String> strUCList=wcStr.stream().map(String :: toUpperCase).collect(Collectors.toList());
		
		System.out.println(strUCList);
	}
}

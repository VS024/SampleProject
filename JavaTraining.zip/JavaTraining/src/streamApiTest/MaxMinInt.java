package streamApiTest;

import java.util.Arrays;
import java.util.List;

public class MaxMinInt {
	public static void main(String[] args) {
		List<Integer> intList= Arrays.asList( 25,5,43,82,14,28,37,65,90);
		
		Integer maxNum = intList.stream().max(Integer:: compare).orElse(null);
		
		System.out.println(maxNum);
		
		Integer minNum= intList.stream().min(Integer:: compare).orElse(null);
	}
}

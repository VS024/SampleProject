package streamApiTest;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SortStringList {

	public static void main(String[] args) {
		List<String> strList= Arrays.asList("Red", "Green", "Blue", "Pink", "Brown","Rose", "Rabbit");
		List<String> sortedstrList= strList.stream().sorted().collect(Collectors.toList());
		System.out.println(sortedstrList);
		
		
		List<String> dscndsortedstrList= strList.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		
		System.out.println(dscndsortedstrList+ " DscOrder");
	}
}

package streamApiTest;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DuplicateRemoval {

	public static void main(String[] args) {
		List<Integer> numList= Arrays.asList(2,4,15,12,3,4,5,6,7,8,9,12,13,14,15);
		
		Map<Integer, Integer> numMap= new HashMap<>();
		
		for(Integer num: numList) {
			if(numMap.containsKey(num)) {
				numMap.put(num, numMap.get(num)+1);
			}else
				numMap.put(num, 1);
		}
		System.out.println(numMap);
//		numList.stream().distinct().collect(Collectors.toList());
//		
//		List<Integer> noDuplct= numList.stream().distinct().collect(Collectors.toList());
//		
//		System.out.println(noDuplct+ " list w/o duplicate");
	}
}

package streamApiTest;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GroupByTest {

	public static void main(String[] args) {
		List<Employee> employees = new ArrayList<>();
		employees.add(new Employee(5000, "Khan", "khan@gmail.com", "A"));
		employees.add(new Employee(4000, "Ajmul", "ajmul@gmail.com", "B"));
		employees.add(new Employee(10000, "Adyan", "adyan@gmail.com", "C"));
		employees.add(new Employee(10000, "Akram", "akram@gmail.com", "D"));
		employees.add(new Employee(20000, "Almas", "almas@gmail.com", "A"));
		employees.add(new Employee(30000, "Ayath", "ayath@gmail.com", "C"));
		employees.add(new Employee(50000, "Ahemath", "ahemath@gmail.com", "B"));
		
		Map<String, List<Employee>> groupByGrade = employees.stream().collect(Collectors.groupingBy(Employee::getGrade));
		int ct= (int) employees.stream().count();
		System.out.println("Count the number of employee" + ct);
		for(Map.Entry mapEntry: groupByGrade.entrySet()) {
			System.out.println(mapEntry.getKey()+ " : " + mapEntry.getValue());
		}
//		groupByGrade.forEach((key,value)-> {
//			
//			//System.out.println(key+ "Key");
//			value.forEach(employee -> System.out.println(employee.salary+ " "+ employee.name+ " "+ employee.grade));
//		});
	}
}

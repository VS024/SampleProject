package streamApiTest;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CountStringStartsWIthLetter {

	public static void main(String[] args) {
		List < String > colors = Arrays.asList("Red", "Green", "Blue", "Pink", "Brown","Rose", "Rabbit");
		colors.stream().filter(s->s.startsWith("B")).count();
		char strtsWith= 'b';
		String srtLetter= "R";
		long ctr =  colors.stream().filter(s->s.startsWith(srtLetter)).count();
		
		System.out.println("Number of string starts with R : "+ ctr );
		
		colors.stream().filter(p->p.startsWith(String.valueOf(strtsWith))).collect(Collectors.toList());
		System.out.println(colors);
	}
}

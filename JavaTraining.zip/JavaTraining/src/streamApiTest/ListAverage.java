package streamApiTest;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ListAverage{
	public static void main(String[] args) {
		List<Integer> intList= new ArrayList<>();
		
		intList.add(2);
		intList.add(5);
		intList.add(29);
		intList.add(92);
		intList.add(72);
		intList.add(32);
		intList.add(21);
		//Double avrg= intList.stream().collect(Collectors.averagingInt(n-> n));
		double avrg= intList.stream().mapToInt(Integer::intValue).average().orElse(0);
		System.out.println(avrg);
	}
}
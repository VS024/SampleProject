package streamApiTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FlatMapTest {

	
	public static void main(String[] args) {
		List<String> productList1= Arrays.asList("Scanner", "Projector", "Light Pen");
		List<String> productList2= Arrays.asList("Pen Drive", "Charger", "WIFI Adapter", "Cooling Fan");  
		List<String> productList3=  Arrays.asList("Scanner", "Projector", "Light Pen"); 
		List<String> productlist4 = Arrays.asList("CPU Cabinet", "WebCam", "Charger", "USB Light", "Microphone", "Power cable");
		
		List<List<String>> allProductList= new ArrayList<>();
		allProductList.add(productList1);
		allProductList.add(productList2);
		allProductList.add(productList3);
		allProductList.add(productlist4);
		//List<Stream<String>> flatMapList = allProductList.stream().map(pList->pList.stream()).collect(Collectors.toList());   
		List<String> flatMapList1= allProductList.stream().flatMap(pList-> pList.stream()).collect(Collectors.toList());
	//	System.out.println("List After Applying Mapping: \n"+ flatMapList); 
		System.out.println("List After Applying Flat Mapping and Flattening Operation: \n"+ flatMapList1);   
	}
}

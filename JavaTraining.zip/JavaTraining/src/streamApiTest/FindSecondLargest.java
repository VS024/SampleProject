package streamApiTest;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class FindSecondLargest {

	public static void main(String[] args) {
		List < Integer > nums = Arrays.asList(1, 17, 54, 14, 14, 33, 45, -11,-10);
		Integer secondSmallest = nums.stream().distinct().sorted((a,b) -> Integer.compare(a, b)).skip(2).findFirst().orElse(null);
		Optional<Integer> fifthSmallest= nums.stream().distinct().sorted().skip(4).findFirst();
		Integer thirdLargest= nums.stream().distinct().sorted((a,b)-> Integer.compare(a, b)).skip(3).findFirst().orElse(null);
		System.out.println(fifthSmallest+ "fifthSmallest");
		System.out.println(secondSmallest);
		
		Integer secondLargest= nums.stream().sorted((a,b) -> Integer.compare(b, a)).skip(1).findFirst().orElse(null);
		System.out.println(secondLargest);
	}
}

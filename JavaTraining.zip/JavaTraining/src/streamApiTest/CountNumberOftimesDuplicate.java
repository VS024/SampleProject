package streamApiTest;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class CountNumberOftimesDuplicate {

	public static void main(String[] args) {
		
		String str= "Alice is girl Alice is bob Alice and Bob is boy";
		
		Map<String, Integer> strMap= new HashMap<>();
		
		 String[] words = str.split(" ");
		
		System.out.println(words);
		for(String word: words) {
			
			if(strMap.containsKey(word)) {
				strMap.put(word, strMap.get(word)+1);
			}else
				strMap.put(word, 1);
		}
		System.out.println(strMap);
 	}
}

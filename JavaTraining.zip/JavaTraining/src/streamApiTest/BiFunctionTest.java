package streamApiTest;

import java.util.function.BiFunction;
import java.util.function.Function;

public class BiFunctionTest {

public static void main(String[] args) {
	//BiFunction<Integer, Integer, Integer> f1= (a,b)-> a+b;
	
	BiFunction<Integer, Integer, Integer> biFnc= (a,b)-> a/b;
	
	//System.out.println(f1.apply(3, 19));
	
	Function<Integer, Integer> f2= a-> a*5; 
	//System.out.println(f1.andThen(f2).apply(16, 14));
	System.out.println(biFnc.andThen(f2).apply(20, 4));
}
}

package streamApiTest;

import java.util.Arrays;
import java.util.List;

public class SumOddEven {

	public static void main(String[] args) {
		List<Integer> numList= Arrays.asList(2,3,4,5,6,7,8,9,12,13,14,15);
		int sum=0;
		int evenSum= numList.stream().filter(nums-> nums%2==0).mapToInt(Integer:: intValue).sum();
		
		int oddSum= numList.stream().filter(nums-> nums%2!=0).mapToInt(Integer:: intValue).sum();
		
		System.out.println(evenSum + "Sum of even number");
		
		System.out.println(oddSum+ "Sum of odd number");
	}
}

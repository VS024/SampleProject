package JavaStreamTest;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Product4{  
    int id;  
    String name;  
    float price;  
    public Product4(int id, String name, float price) {  
        this.id = id;  
        this.name = name;  
        this.price = price;  
    }  
} 
public class CollectionFilter {
	
	public static void main(String[] args) {
		List<Product4> productsList= new ArrayList<>();
	    productsList.add(new Product4(1,"HP Laptop",25000f));  
        productsList.add(new Product4(2,"Dell Laptop",30000f));  
        productsList.add(new Product4(3,"Lenevo Laptop",28000f));  
        productsList.add(new Product4(4,"Sony Laptop",28000f));  
        productsList.add(new Product4(5,"Apple Laptop",90000f)); 
        
productsList.stream().filter(pl-> pl.price>20000).map(p->p.price).collect(Collectors.toSet()).forEach(System.out::println);;
        Stream<Product4> filterData= productsList.stream().filter((pl)->pl.price>25000);
        
        List<String> filtrPrice= productsList.stream().
        		filter((pl2)-> pl2.price>25000).
        		map(pl2->pl2.name).
        		collect(Collectors.toList());
        
        filterData.forEach((plItr)-> System.out.println(plItr.price));
        
        System.out.println("****************************");
        
        System.out.println(filtrPrice);
		
	}

}

package encapsulationTest;

public class StudentEncp {

	private String name="GHIT";

	public String getName() {
		return name;
	}

//	public void setName(String name) {
//		this.name = name;
//	}
}

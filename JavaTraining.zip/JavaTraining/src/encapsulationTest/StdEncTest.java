package encapsulationTest;

public class StdEncTest {

	public static void main(String[] args) {
		StudentEncp se= new StudentEncp();
		//se.getName();
		//se.setName("Ravi");
		System.out.println(se.getName());
	}
}

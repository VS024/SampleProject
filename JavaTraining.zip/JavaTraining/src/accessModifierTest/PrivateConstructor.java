package accessModifierTest;

public class PrivateConstructor {
//A class cannot be private or protected except nested class
	private int x=10;
	private PrivateConstructor() {//private constructo
		System.out.println("Inside private constructor " + x);
	}
	public static void main(String[] args) {
		PrivateConstructor pc=new PrivateConstructor();
		
	}
}

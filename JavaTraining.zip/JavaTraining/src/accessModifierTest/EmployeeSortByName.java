package accessModifierTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


class Employee{
	
	int id;
	String name;
	
	
	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
public class EmployeeSortByName {


	public static void main(String[] args) {
		Employee empobj= new Employee(1, "Ram");
		Employee empobj2= new Employee(7, "Ramesh");
		Employee empobj3= new Employee(12, "Shyam");
		Employee empobj4= new Employee(81, "Manoj");
		Employee empobj5= new Employee(41, "Rishi");
		
		List<Employee> empList= new ArrayList<>();
		empList.add(empobj);
		empList.add(empobj2);
		empList.add(empobj3);
		empList.add(empobj4);
		empList.add(empobj5);
		
		
		Comparator<Employee> cmp= Comparator.comparing(Employee::getName);
		
		Collections.sort(empList, cmp);
	//	Stream string= empList.stream().map(list-> list.name).collect(Collectors.toList());
		
		for(Employee emp: empList) {
			System.out.println(emp.name);
		}

	}
}

/**
 * 
 */
/**
 * @author VS67380
 *
 */
module JavaTraining {
}
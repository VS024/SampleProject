package functionalInterface;

@FunctionalInterface
interface Sayable8{//functional interface can have methods of object class
	void say();
	int hashCode();
	String toString();
}
public class FunctionalInterfaceObjectClassMethod implements Sayable8{

	@Override
	public void say() {
		System.out.println("Inside functional interface method");
		
	}
	public static void main(String[] args) {
		FunctionalInterfaceObjectClassMethod fio= new FunctionalInterfaceObjectClassMethod();
		fio.say();
		fio.hashCode();
	}

}

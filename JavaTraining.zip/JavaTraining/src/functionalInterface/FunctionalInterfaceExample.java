package functionalInterface;

@FunctionalInterface
interface Sayable7{
	void say(String msg);
}
public class FunctionalInterfaceExample implements Sayable7{

	@Override
	public void say(String msg) {
		System.out.println(msg);
	}
	public static void main(String[] args) {
		FunctionalInterfaceExample fi= new FunctionalInterfaceExample();
		fi.say("Testing function Interfave");
	}

}

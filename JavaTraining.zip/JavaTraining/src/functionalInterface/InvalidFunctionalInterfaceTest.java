package functionalInterface;

interface Sayable9{
	//void say();
	default void SaySomething(String msg) {
		System.out.println("Hello welcome to non functional Interface");
	}
}
@FunctionalInterface
interface InvalidFunctionalInterfaceTest extends Sayable9{//A functional interface can extends another interface only when it does not have any abstract method
 void doIt();
}

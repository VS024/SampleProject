package StrProgTest;

import java.util.Arrays;
import java.util.List;

public class CountStrChar {

	public static void main(String[] args) {
		
		String myStr= "The best of both worlds";
		List<String> strList= Arrays.asList(myStr.split(" "));
		System.out.println(strList.size());
		int count= (int) strList.stream().count();
//		for(String str: strList) {
//			
//		}
//		int count=0;
//		int strLnth= myStr.length();
//		System.out.println(strLnth);
//		for(int i=0; i<strLnth; i++) {
//			if(myStr.charAt(i) != ' ')    
//                count++;    
//        }   
		System.out.println("Total number of characters in a string: " + count); 
		}
				
	}

package treeSetTest;

import java.util.Iterator;
import java.util.TreeSet;

public class SetOFNumberGreaterThenGiven {

	public static void main(String[] args) {
		TreeSet<Integer> trSet= new TreeSet<>();
		
		TreeSet<Integer> headSetTr= new TreeSet<>();
		
		trSet.add(1);
		//trSet.add(5);
		trSet.add(8);
		trSet.add(4);
		trSet.add(7);
		trSet.add(0);
		trSet.add(2);
		trSet.add(6);
		trSet.add(3);
		trSet.add(9);
		
		headSetTr= (TreeSet<Integer>) trSet.headSet(7);
		System.out.println(trSet.ceiling(5));//give just greater or equalto the given number, if none found return "null"
		System.out.println(trSet.floor(5));//give just lesser or equal to the given number, if none found return "null"
		Iterator<Integer> itr= headSetTr.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
	}
}

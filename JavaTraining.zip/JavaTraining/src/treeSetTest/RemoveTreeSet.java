package treeSetTest;

import java.util.TreeSet;

public class RemoveTreeSet {
	public static void main(String[] args) {
		TreeSet<Integer> tree_num= new TreeSet<>();
		
		tree_num.add(10);
		   tree_num.add(22);
		   tree_num.add(36);
		   tree_num.add(25);
		   tree_num.add(16);
		   tree_num.add(70);
		   tree_num.add(82);
		   tree_num.add(89);
		   tree_num.add(14);
		   
		   tree_num.remove(25);
		   
		   
		   System.out.println(tree_num.pollLast());//Retrieve and remove the last element of a tree set
		   System.out.println(tree_num.pollFirst());//Retrieve and remove the first element of a tree set
		   
		   System.out.println(tree_num);
	}
}

package treeSetTest;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class ReverseTreeSet {

	public static void main(String[] args) {
		TreeSet<String> trSet= new TreeSet<>();
		trSet.add("ae");
		trSet.add("ou");
		trSet.add("ie");
		trSet.add("eu");
		TreeSet<String> trSet2= new TreeSet<>();
		trSet2.add("AE");
		trSet2.add("EI");
		trSet2.add("IU");
		trSet.addAll(trSet2);
	//	Iterator<String> trItr= trSet.iterator();
		Iterator<String> trItr= trSet.descendingIterator();
//		for(String str: trSet) {
//			System.out.println(str);
//		}
		
		System.out.println("First element of treeset: "+trSet.first());
		System.out.println("Last element of treeset: "+trSet.last());
		System.out.println(trSet.size());
		while(trItr.hasNext()) {
			System.out.println(trItr.next());
		}
	}
}

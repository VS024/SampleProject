package aggregationTest;

public class EmployeeTest {

	int empid;
	String name;
	static String company = "Zensar";
	
	AddressTest address;//Employee has an entity reference address, so relationship is Employee HAS-A address

	public EmployeeTest(int empid, String name, AddressTest address) {
		this.empid = empid;
		this.name = name;
		this.address = address;
	}
	public void display() {
		System.out.println(empid + " " + name+ " " + company+ " ");
		System.out.println(address.city + " "+ address.country + " "+ address.pin + " ");
	}
	public static void main(String[] args) {
		
		AddressTest at=new AddressTest(123, "Karnataka", "Bharat");
		EmployeeTest et= new EmployeeTest(1, "Laxmi" +company, at );
		et.display();
		
	}
	

}

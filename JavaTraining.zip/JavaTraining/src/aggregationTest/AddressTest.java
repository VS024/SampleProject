package aggregationTest;

public class AddressTest {

	int pin;
	String city;
	String country;
	public AddressTest(int pin, String city, String country) {
		this.pin = pin;
		this.city = city;
		this.country = country;
	}
	
}

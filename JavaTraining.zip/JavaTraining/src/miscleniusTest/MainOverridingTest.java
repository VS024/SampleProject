package miscleniusTest;

public class MainOverridingTest extends MainOverloadingTest{
	
@Override
public void main(int args) {
	// TODO Auto-generated method stub
	super.main(args);
}
//We cant overload java main(), static() are class level methods
public static void main(String[] args) {
	System.out.println("Inside child main");
}
}

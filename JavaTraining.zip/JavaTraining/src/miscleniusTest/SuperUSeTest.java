package miscleniusTest;

class Person{
	int empId;
	String name;
	public Person(int empId, String name) {
		this.empId = empId;
		this.name = name;
	}
}
class Employee5 extends Person{
	float salary;
	public Employee5(int empId, String name, float salary) {
		super(empId, name);
		this.salary = salary;
	}
	void display() {
		System.out.println(empId+ " " + name + " "+ salary);
	}
}
public class SuperUSeTest {
	public static void main(String[] args) {
		Employee5 emp5= new Employee5(2, "Radha", 200000);
		emp5.display();
	}
}

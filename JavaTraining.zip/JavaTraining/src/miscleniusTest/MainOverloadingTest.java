package miscleniusTest;

public class MainOverloadingTest {

	public static void main(String[] args) {
		System.out.println("inside Java Parent main");
		MainOverloadingTest mot= new MainOverloadingTest();
		mot.main(4);
	}
	
	public void main(int args) {
		System.out.println("Inside Overriding main method"+ " : "+ args);
	}
}

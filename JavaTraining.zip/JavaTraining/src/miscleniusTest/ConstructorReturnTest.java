package miscleniusTest;

public class ConstructorReturnTest {
	
	public ConstructorReturnTest(String args) {
		System.out.println("inside constructor");
		System.out.println("Returning print data" + ": " + args);
	}
	
	public static void main(String[] args) {
		System.out.println("inside main");
		ConstructorReturnTest crt=new ConstructorReturnTest("return data");
		System.out.println(crt);
	}
	

}

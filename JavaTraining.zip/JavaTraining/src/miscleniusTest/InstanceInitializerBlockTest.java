package miscleniusTest;

class Bike{
	int speed;
	Bike(){
		System.out.println("Your bike speed is : "+speed);
	}
	{
		speed=100;
	}
	{
		System.out.println("Instance Initialiser block 1");
	}
	{
		System.out.println("Instance Initialiser block 2");
	}
	
}
public class InstanceInitializerBlockTest {
public static void main(String[] args) {
	Bike bike1= new Bike();
}	
}

package miscleniusTest;

class ClassWOmain {
	//we can run a java program w/o main using static block on or before JDK
	//1.6 after that it is compulsary to have main() to run java programe
	
	static
    {
        System.out.println("Hi look program is running without main() method");
    }
}

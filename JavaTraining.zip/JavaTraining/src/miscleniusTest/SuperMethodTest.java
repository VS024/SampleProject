package miscleniusTest;

class Animal1{
	void eat() {
		System.out.println("Animal eats");
	}
}
class Dog1 extends Animal1{  
	void eat(){
	System.out.println("Dog eating bread...");
	super.eat();
	}  

} 
public class SuperMethodTest {
	public static void main(String[] args) {
	Dog1 dog1=new Dog1();

	dog1.eat();

	
	}
}

package miscleniusTest;

class A{
	A get() {
	return this;	
	}
}
class B extends A{
	@Override
	B get() {//overriding method with different return type
		return this;
	}
	void message() {
		System.out.println("welcome to covarient type");
	}
}
public class CoverientReturnTest {
	public static void main(String[] args) {
		new B().message();
	}
}

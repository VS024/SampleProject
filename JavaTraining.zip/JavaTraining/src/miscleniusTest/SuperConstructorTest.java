package miscleniusTest;

class A5{
	A5(){
		System.out.println("Parent class");
	}
}
class B5 extends A5{
	B5(){
		//super();
		System.out.println("Child class");
	}
	B5(String args){
	//	super();
		System.out.println("Child class parameterized constructor");
	}
	
}
public class SuperConstructorTest {
	public static void main(String[] args) {
		B5 b5= new B5();
		B5 b6= new B5("Parametrised constructor");
		
	}
}

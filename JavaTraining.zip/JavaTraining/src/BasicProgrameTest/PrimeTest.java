package BasicProgrameTest;

public class PrimeTest {

	public static void main(String[] args) {
		int num=19;
		
		PrimeTest pt= new PrimeTest();
		pt.primenum(18);
	}
	
	public void primenum(int num) {
		int checkNum= num/2;
		int count = 0;
		if(num==0 || num ==1) {
			System.out.println("not a prime number");
		}
		for(int i= 1; i<checkNum; i++) {
			int primeNum=0;
			if(num%i==0) {
				count++;
			}
		}
		if(count>2) {
			System.out.println("not a prime number");
		}
		else
			System.out.println("prime number");
	}
}

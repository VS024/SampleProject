package BasicProgrameTest;

public class EvenNumTest {

	public static void main(String[] args) {
		EvenNumTest pnt= new EvenNumTest();
		pnt.evenOddTest(13);
	}
	
	public void evenOddTest(int num) {
		if(num%2==0) {
			System.out.println("its a Even number");
		}else
			System.out.println("its a Odd number");
	}
}

package BasicProgrameTest;

public class FibonacciTest {

	//0,1,1,2,3,5,7,12,19
	int temp1=0, temp2=1, temp3 ;
	public static void main(String[] args) {
		int count=12;
		FibonacciTest ft= new FibonacciTest();
		ft.printFibbonacci(count);
	}
	
	public void printFibbonacci(int count) {
		for(int i=0; i<count; i++) {
			if(i<2)
			{
				System.out.println(i);
		}else
				{
			temp3= temp1 + temp2;
			System.out.println(temp3);
			temp1=temp2;
			temp2=temp3;

				}
		}
	}
}

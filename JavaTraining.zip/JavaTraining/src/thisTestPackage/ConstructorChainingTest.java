package thisTestPackage;

public class ConstructorChainingTest {

	int id;
	String name, course;
	float fee;
	
	ConstructorChainingTest(int id, String name, float fee){
		this.id=id;
		this.name=name;
		this.fee=fee;
	}
	ConstructorChainingTest(int id, String name, float fee, String course){
		this(id,name,fee);//constructor chaining
		this.course=course;
	}
	void display()
	{
		System.out.println("id: "+ id + "name: "+ name +" fee: " + fee + "course: " +course);
	}
	
	public static void main(String[] args) {
		ConstructorChainingTest cct= new ConstructorChainingTest(1, "Sita", 3000);
		ConstructorChainingTest cct1= new ConstructorChainingTest(1, "Geeta", 5000,"BBA");
		cct.display();
		cct1.display();
		
	}
}

package thisTestPackage;

public class ThisCallCurrentClassMethod {
	
	void m(int num) {
		System.out.println("Hello m");
	}
	void n() {
		m(5);//compiler internally calling this.m()
		//this.m();
		System.out.println("Hello n");
	}
	ThisCallCurrentClassMethod(){
		System.out.println("Inside constructore");
	}
	ThisCallCurrentClassMethod(int num){
		System.out.println("Inside arg constructore");
	}
	
	public static void main(String[] args) {
		ThisCallCurrentClassMethod tcctcm = new ThisCallCurrentClassMethod(2);
		tcctcm.n();
	}
}

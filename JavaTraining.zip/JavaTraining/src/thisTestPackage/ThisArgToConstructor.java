package thisTestPackage;

public class ThisArgToConstructor {
	int num=10;
	ThisArgToConstructor obj;
	ThisArgToConstructor(){
		ThisArgToConstructor b= new ThisArgToConstructor(this);
		//System.out.println("This value :" + this.num);
		b.display();
	}
	ThisArgToConstructor(ThisArgToConstructor obj){
		this.obj=obj;
	}
	
	void display() {
		System.out.println(obj.num);//using datamember
		//obj.display();
	}
	public static void main(String[] args) {
		
		ThisArgToConstructor a=new ThisArgToConstructor();
		
	}
}

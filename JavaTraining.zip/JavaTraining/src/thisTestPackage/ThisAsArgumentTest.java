package thisTestPackage;

public class ThisAsArgumentTest {

	void m(ThisAsArgumentTest obj) {
		System.out.println("method m is invoked" +" " + obj);
	}
	void p() {
		m(this);//this passed as an argument in the method
		//System.out.println("method p is invoke");
	}
	public static void main(String[] args) {
		ThisAsArgumentTest taat= new ThisAsArgumentTest();
		//taat.m(taat);
		taat.p();
	}
}

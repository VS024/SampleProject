package thisTestPackage;

public class ThisCallCurrentClassConstructor {
	
	ThisCallCurrentClassConstructor(){
		this(5);
		System.out.println("inside noarg constructor");
	}
	ThisCallCurrentClassConstructor(int x){
		//this();
		System.out.println("inside 2nd construstor" + x);
	}
	public static void main(String[] args) {
		ThisCallCurrentClassConstructor a =new ThisCallCurrentClassConstructor();
		ThisCallCurrentClassConstructor b =new ThisCallCurrentClassConstructor(4);
	}

}

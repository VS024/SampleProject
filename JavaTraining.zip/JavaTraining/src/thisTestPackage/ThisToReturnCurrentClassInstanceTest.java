package thisTestPackage;

public class ThisToReturnCurrentClassInstanceTest {

	ThisToReturnCurrentClassInstanceTest getA(){
		return this;
	}
	void msg() {
		System.out.println("Inside message()");
	}
	public static void main(String[] args) {
	
		new ThisToReturnCurrentClassInstanceTest().getA().msg();;
		
	}
	
	
}

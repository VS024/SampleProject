package thisTestPackage;

public class ThisCurrentClassInstanceTest {
	
	

}

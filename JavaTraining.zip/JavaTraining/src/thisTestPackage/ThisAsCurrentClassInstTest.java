package thisTestPackage;

public class ThisAsCurrentClassInstTest {
	//It is better approach to use meaningful names for variables.
	//So we use same name for instance variables and parameters in real time, and always use this keyword.
	int id;
	String name;
	float fee;
	
//	ThisClassInstTest(int id, String name, float fee){
//		id=id;
//		name=name;
//		fee=fee;
//		
//	}
	
	ThisAsCurrentClassInstTest(int id, String name, float fee){
		this.id=id;
		this.name=name;
		this.fee=fee;
		
	}
	
	void display() {
		System.out.println("id: "+ id + " "+ "name : "+ name +" "+ "fee : " +  " "+ fee);
	}
	public static void main(String[] args) {
		ThisAsCurrentClassInstTest tct= new ThisAsCurrentClassInstTest(1, "Ram", 20);
		tct.display();
		
	}
}

package thisTestPackage;

public class ProveThisReferCurrentClassInstanceTest {
 
	void m() {
		System.out.println(this + "inside method");
	}
	public static void main(String[] args) {
		ProveThisReferCurrentClassInstanceTest ptrccit= new ProveThisReferCurrentClassInstanceTest();
		System.out.println(ptrccit + "inside main()");
		ptrccit.m();
	}
}

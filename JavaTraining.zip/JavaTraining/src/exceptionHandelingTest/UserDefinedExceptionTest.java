package exceptionHandelingTest;

public class UserDefinedExceptionTest extends Exception{
	public UserDefinedExceptionTest(String str) {
		super(str);
		
	}
	
}

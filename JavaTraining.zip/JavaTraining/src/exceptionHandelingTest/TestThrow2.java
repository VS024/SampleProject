package exceptionHandelingTest;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class TestThrow2 {

	public static void throwUncheckedExcptn() throws FileNotFoundException{
		FileReader file = new FileReader("");
		BufferedReader fileInput =new BufferedReader(file);
		throw new FileNotFoundException();
		
	}
	public static void main(String[] args) {
	try {
		throwUncheckedExcptn();
	}catch(FileNotFoundException fnfex) {
		fnfex.printStackTrace();  
	}
	System.out.println("Rest of the programe");
	}
}

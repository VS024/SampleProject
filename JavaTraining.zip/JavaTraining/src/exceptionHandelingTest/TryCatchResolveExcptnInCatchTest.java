package exceptionHandelingTest;

public class TryCatchResolveExcptnInCatchTest {

	public static void main(String[] args) {
		  int i=50;  
	        int j=0;  
	        int data;  
		try {
			data= i/j;
			
		}catch(Exception ex) {
			System.out.println(i/(j+2));  
			
		}
	}
}

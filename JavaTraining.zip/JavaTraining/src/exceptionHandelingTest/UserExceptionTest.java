package exceptionHandelingTest;

public class UserExceptionTest {

	public static void main(String[] args) {
		try {
			throw new UserDefinedExceptionTest("Fall into user define exception");
		}catch(UserDefinedExceptionTest ude) {
			System.out.println("Caught the exception");
			System.out.println(ude.getMessage());  
		}
	}
}

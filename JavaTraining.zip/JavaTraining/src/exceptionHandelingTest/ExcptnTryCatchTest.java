package exceptionHandelingTest;

public class ExcptnTryCatchTest {

	public static void main(String[] args) {
		try {
			int data= 100/0;
			
		}catch(ArithmeticException ex){
			System.out.println(ex.getMessage());
			
		}
		System.out.println("The show must go on");
	}
}

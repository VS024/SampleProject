package exceptionHandelingTest;

public class NumberFormateExceptionTest {

	public static void main(String[] args) {
		String str=null;
		try {
			String s="abc";  
			int i=Integer.parseInt(s);
			System.out.println(i);
		}catch(NumberFormatException nfe) {
			System.out.println(nfe.getMessage());
		}
		try {
			System.out.println(str.length());
		}catch(NullPointerException npe) {
			System.out.println(npe.getLocalizedMessage());
		}
	}
}

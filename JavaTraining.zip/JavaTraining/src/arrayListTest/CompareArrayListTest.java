package arrayListTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CompareArrayListTest {
	public static void main(String[] args) {
		ArrayList<String> c1= new ArrayList<String>();
	    c1.add("Red");
	    c1.add("Green");
	    c1.add("Black");
	    c1.add("White");
	    c1.add("Pink");
			  
	    ArrayList<String> c2= new ArrayList<String>();
	    c2.add("Red");
	    c2.add("Green");
	    c2.add("Black");
	    c2.add("Pink");
	    
	    ArrayList<String> c3= new ArrayList<String>();
	    for(String lcheck:c1) {
	    	
	    	c3.add(c2.contains(lcheck)?lcheck: "no");
	    }
	    System.out.println(c3);
	    
	}

}

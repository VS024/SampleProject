package arrayListTest;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListTest1 {
	 public static void main(String args[])
	    {
	       List<String> color= new ArrayList<>();
	        color.add("Red");
	        color.add("Yellow");
	        color.add("Green");
	        color.add(0,"Blue");
	        System.out.println(color);
	        //Itterate using iterator
	        System.out.println("Itterate using iterator");
	        Iterator itr= color.iterator();
	        while(itr.hasNext()) {
	        	System.out.println(itr.next());
	        }
	        
	    //  Itterate using for-each	 
	        System.out.println("Itterate using for-each	 ");
	        for(String clr:color){
	            System.out.println(clr);
	        }
	        
	        
	    }
}

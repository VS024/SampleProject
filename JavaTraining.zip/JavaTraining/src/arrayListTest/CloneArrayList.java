package arrayListTest;

import java.util.ArrayList;
import java.util.Collections;

public class CloneArrayList {

	public static void main(String[] args) {
		ArrayList<String> c1= new ArrayList<String>();
	    c1.add("Red");
	    c1.add("Green");
	    c1.add("Black");
	    c1.add("White");
	    c1.add("Pink");
	    ArrayList<String> c2= (ArrayList<String>) c1.clone();
	    System.out.println(c1);
	    System.out.println("After cloning" + c2);
	}
}

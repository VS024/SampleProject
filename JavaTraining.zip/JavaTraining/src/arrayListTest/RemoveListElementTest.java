package arrayListTest;

import java.util.ArrayList;
import java.util.List;

public class RemoveListElementTest {
	public static void main(String[] args) {
		 List<String> color= new ArrayList<>();
		color.add("Red");
        color.add("Yellow");
        color.add("Green");
        color.add(0,"Blue");
        color.remove(3);
        System.out.println(color);
	}
}

package arrayListTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class Main
{
	public static void main(String[] args) {
		Integer[] original = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
		int splitSize = 3;
		
	
		/* expected Output 
		[0, 1, 2]
		[3, 4, 5]
		[6, 7, 8]
		[9]
		*/
	
		splitArray(original, splitSize);
		//list.forEach(splitArray -> System.out.println(Arrays.toString(splitArray)));
	}
	
	public static void splitArray(Integer[] array, int splitSize) {

		List<Integer> list1 = new ArrayList<>();
		for(int i= 0; i< array.length; i++) {
			

			if(i%splitSize<splitSize) {
				list1.add(array[i]);
				
				
		}
				if((i+1)%splitSize==0) {
					System.out.println(list1);
					list1=	new ArrayList<>();
					
			}
				
		}System.out.println(list1);
	}
}




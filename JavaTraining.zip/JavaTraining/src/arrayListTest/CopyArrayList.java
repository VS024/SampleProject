package arrayListTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CopyArrayList {
	public static void main(String[] args) {
		 List<String> color= new ArrayList<>();
		color.add("Red");
       color.add("Yellow");
       color.add("Green");
       color.add(0,"Blue");
       List<String> colorCopy= new ArrayList<>();
       colorCopy.add("A");
       colorCopy.add("B");
       colorCopy.add("C");
       colorCopy.add("Green");
     //it will copy the element colorCopy in color  
       Collections.copy(color, colorCopy );
       //o/p [A, B, C, Green]
       System.out.println(color);
	}
}

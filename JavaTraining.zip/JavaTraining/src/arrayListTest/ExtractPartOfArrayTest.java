package arrayListTest;

import java.util.ArrayList;
import java.util.List;

public class ExtractPartOfArrayTest {
	public static void main(String[] args) {
		List<String> list_Strings = new ArrayList<String>();
		  list_Strings.add("Red");
		  list_Strings.add("Green");
		  list_Strings.add("Orange");
		  list_Strings.add("White");
		  list_Strings.add("Black");
		  
		  list_Strings.subList(1, 2);
		  System.out.println(list_Strings.subList(1, 2));
		  //System.out.println(list_Strings.subList(2, 4));
	}
}

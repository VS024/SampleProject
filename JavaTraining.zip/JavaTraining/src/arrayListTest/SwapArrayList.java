package arrayListTest;

import java.util.ArrayList;
import java.util.Collections;

public class SwapArrayList {

	public static void main(String[] args) {
		ArrayList<String> c1= new ArrayList<String>();
	    c1.add("Red");
	    c1.add("Green");
	    c1.add("Black");
	    c1.add("White");
	    c1.add("Pink");
	    
	    ArrayList<String> c2= new ArrayList<String>();
	    Collections.swap(c1, 2, 4);
	    
	    System.out.println(c1);

	}
}

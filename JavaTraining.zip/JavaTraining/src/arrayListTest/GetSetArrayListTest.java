package arrayListTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GetSetArrayListTest {

	public static void main(String[] args) {
		 List<String> color= new ArrayList<>();
	        color.add("Red");
	        color.add("Yellow");
	        color.add("Green");
	        color.add(0,"Blue");
	        List<String> colorCopy= new ArrayList<>();
	        System.out.println(color);
	        colorCopy.addAll(color);
	        System.out.println(colorCopy);
	        
	        System.out.println(color.get(2));
	        color.set(2, "Pink");
	        System.out.println("color after changing " +color.get(2));
	       Collections.sort(color);
	       System.out.println(color);
	       
	}
}

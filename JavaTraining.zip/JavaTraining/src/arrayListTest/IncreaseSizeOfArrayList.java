package arrayListTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class IncreaseSizeOfArrayList {

	public static void main(String[] args) {
		ArrayList<String> color= new ArrayList<>(2);
		
		color.add("Red");
		color.add("Blue");
		color.add("Green");
		color.add("Black");
		System.out.println(color);
		
		color.set(2, "Purple");
		System.out.println(color);
		//color.ensureCapacity(10);
		//System.out.println(color.size());
		
		int listSize=color.size();
		System.out.println("Getting list by index ");
		for(int i=0; i<listSize; i++) {
			
			System.out.println( i + " : "+color.get(i));
		}
	}
}

package LinkedListTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class ConvertListToArray {

	public static void main(String[] args) {
		LinkedList<String> llist= new LinkedList<>();
		
		llist.add("A");
		llist.add("A");
		llist.add("A");
		llist.add("A");
		llist.add("A");
		llist.add("A");
		
		System.out.println(llist.toArray());
		
		//System.out.println(llist);
		List<String> arrList= new ArrayList<>(llist);
		System.out.println(arrList);
		
	}
}

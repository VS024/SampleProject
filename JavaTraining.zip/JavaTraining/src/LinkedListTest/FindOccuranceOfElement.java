package LinkedListTest;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;

public class FindOccuranceOfElement {

	public static void main(String[] args) {
		LinkedList<String> list= new LinkedList<>();
		list.add("A");
		list.add("C");
		list.add("B");
		list.add("C");
		list.add("F");
		list.add("G");
		list.add("F");
		list.add("C");
		list.add("F");
		list.add("A");
		list.remove(0);
		list.removeFirst();
		list.removeLast();
		System.out.println(list);
		//find 1st and last occuance of "F"
		System.out.println(list.indexOf("F"));
		System.out.println(list.lastIndexOf("F"));
		
		int count=0;
		Iterator itr= list.iterator();
		
		while(itr.hasNext()) {
			String str1= (String) itr.next();
			if(str1.equals("F")) {
				count++;
			}
		}
		System.out.println("Occurance of F is: " +count);
		
		//Getting index of given element
		for(int i=0; i<list.size(); i++) {
			if(list.get(i)=="F")
			System.out.println("index of F: "+ i);
			
		}
		
		LinkedList<String> list2= new LinkedList<>();
		list2.add("Z");
		list2.add("Y");
		list2.add("X");
		list.addAll(list2);
		Collections.swap(list ,1 , 2);
		Collections.shuffle(list);
		System.out.println(list);
	}
}

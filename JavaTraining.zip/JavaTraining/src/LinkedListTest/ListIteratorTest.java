package LinkedListTest;


import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class ListIteratorTest {

	public static void main(String[] args) {
		LinkedList<String> slist= new LinkedList<>();
		slist.add(0, "start");//will add the element after Iterating the list
		slist.addFirst("AtFirst");//"AddFirst" preference is more then list.add(0, "E")
		slist.add("A");
		slist.add("B");
		slist.add("C");
		slist.add("D");
		slist.add("E");
		

		slist.addLast("End");
		
		//Using ListIterator
		ListIterator litr= slist.listIterator(2);
		System.out.println("List Iterating "+ slist);
		while(litr.hasNext()) {
		
			System.out.println(litr.next());
		}

		System.out.println("List Iterating in back direction");
		
		while(litr.hasPrevious()) {
			System.out.println(litr.previous());
		}
		
		//Iterate using Iterator
		System.out.println("Iterating with Iterator");
		Iterator itr= slist.iterator();
		while(litr.hasNext()) {
			System.out.println(litr.next());
		}
//reverse using iterator
		System.out.println("Revert Iterating with Iterator");
		Iterator revItr= slist.descendingIterator();
		while(revItr.hasNext()) {
			System.out.println(revItr.next());
		}
		
	}

}

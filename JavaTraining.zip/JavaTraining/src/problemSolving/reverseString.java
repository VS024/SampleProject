package problemSolving;

public class reverseString {

	public static void main(String[] args) {
		rverse("Hello World");
		reverseStringBuilder("Reverting String builder");
		String input = "java-w3wschools blog";
		 printReverse(input, input.length()-1);
		 int num = 4567;
		 reverseMethod(num);
	}
	
	public static void rverse(String str) {

		  String revString = "";

		  for (int i = str.length() - 1; i >= 0; --i) {
		   revString += str.charAt(i);
		  }
		  System.out.println(revString);
	}


		 private static void printReverse(String s, int pos) {
		  if (pos > -1) {
		   System.out.print(s.charAt(pos));
		   printReverse(s, pos - 1);
		  }
	}
	public static String reverseStringBuilder(String str) {
		
		StringBuilder strBldr = new StringBuilder(str);
		System.out.println(strBldr.reverse().toString());
		return strBldr.reverse().toString();
		
	}
	public static void reverseMethod(int number) {
	    if (number < 10) {
	        System.out.println(number);
	        return;
	    } else {
	        System.out.print(number % 10);
	        reverseMethod(number / 10);
	    }
	}
}

package internationalizationTest;

import java.text.NumberFormat;
import java.util.Currency;
import java.util.Locale;

public class InternalizationCurrencyTest {
	static void printCurrency(Locale locale) {
		double dbl= 1294758.3982;
		
		NumberFormat formatter= NumberFormat.getCurrencyInstance(locale);
		String currency= formatter.format(dbl);
		System.out.println(currency + "for the loclae : " + locale);
	}
	
	public static void main(String[] args) {
		printCurrency(Locale.CANADA);
		printCurrency(Locale.CHINA);
		printCurrency(Locale.FRANCE);
		printCurrency(Locale.GERMAN);
	}
}

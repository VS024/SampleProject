package internationalizationTest;

import java.util.Locale;

public class LocaleTest {

	public static void main(String[] args) {
		Locale indLocale = Locale.getDefault();
		
		System.out.println(indLocale.getDisplayCountry());
		System.out.println(indLocale.getDisplayLanguage());
		System.out.println(indLocale.getDisplayName());
		System.out.println(indLocale.getISO3Country());
		System.out.println(indLocale.getISO3Language());
	}
}

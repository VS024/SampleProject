package internationalizationTest;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class InternationalizingTimeTest {
	static void printTime(Locale locale) {
		
		DateFormat formatter= DateFormat.getTimeInstance();
		Date currentDate= new Date();
		String time= formatter.format(currentDate);
		System.out.println(time + " in locale" + locale);
	}

	public static void main(String[] args) {
		printTime(Locale.CANADA);
		printTime(Locale.CHINA);
		printTime(Locale.FRANCE);
		printTime(Locale.UK);
		printTime(Locale.US);
	}
}

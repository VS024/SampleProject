package inheritanceTest;

class A{
	void display() {
		System.out.println("Inside class A");
	}
}
class B extends A{
	void display1() {
		System.out.println("Inside class B");
	}
}
class C extends A{
	void display2() {
		System.out.println("Inside class c");
	}
}

public class HierarchicalInheritanceTest {
	public static void main(String[] args) {
		A a= new A();
		B b= new B();
		C c= new C();
		a.display();
		b.display();
		b.display1();
		c.display();
		c.display2();
	}
	

}

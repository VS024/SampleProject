package inheritanceTest;

class CountryTest{
	String country="India";
	void countryName() {
		System.out.println("In country " + country);
	}
}
class StateNameTest extends CountryTest{
	String state= "Karnataka";
	void stateName() {
		System.out.println("In state " + state);
	}
}
class CityNameTest extends StateNameTest{
	String city ="Bangalor";
	String state= "Bihar";
	String country="Bharat";
	void countryName() {
		System.out.println("In country " + country);
	}
	void stateName() {
		System.out.println("In state " + state);
	}
	void cityName() {
		System.out.println("In city "+ city );
	}
}
public class MultilevelInheritanceTest {

public static void main(String[] args) {
	CountryTest ct =new CountryTest();
	StateNameTest snt= new StateNameTest();
	CityNameTest cnt =new CityNameTest();
	StateNameTest snt2 =new CityNameTest();//java.lang.Error: Unresolved compilation problem: 
	
	ct.countryName();
	snt.countryName();
	snt.stateName();
	//snt2.cityName();//The method cityName() is undefined for the type StateNameTest
	cnt.countryName();
	cnt.stateName();
	cnt.cityName();
}
}

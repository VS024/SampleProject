package inheritanceTest;

class BankInterest {

	int getRateOfInterest(){
		return 0;
	}
}
class SBI extends BankInterest{
	int getRateOfInterest(){
		return 8;
	}
}
class ICICI extends BankInterest{
	int getRateOfInterest(){
		return 9;
	}
}
class HDFC extends BankInterest{
	int getRateOfInterest(){
		return 12;
	}
}

public class BankTest{
	public static void main(String[] args) {
		SBI sbi=new SBI();
		ICICI icici= new ICICI();
		HDFC hdfc = new HDFC();
		System.out.println(sbi.getRateOfInterest());
		System.out.println(icici.getRateOfInterest());
		System.out.println(hdfc.getRateOfInterest());
	}
}
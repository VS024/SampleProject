package inheritanceTest;

class Animal{
	void speak() {
		System.out.println("Animal speaking");
	}
	void eat() {
		System.out.println("Animal eating");
	}
}
class Dog extends Animal{
	void speak() {
		System.out.println("Dog Barks");
	}
	void eat() {
		System.out.println("Dog drink milk");
	}
}
public class SingleInheritanceTest {
		public static void main(String[] args) {
			Animal animal= new Animal();
			Dog dog= new Dog();
			Animal animal2= new Dog();
		//	Dog dog3= (Dog)new Animal();//java.lang.ClassCastException:
			animal.eat();
			animal2.eat();
			dog.eat();
			dog.speak();
			//dog3.eat();//class inheritanceTest.Animal cannot be cast to class inheritanceTest.Dog
			
		}
	
}

package inheritanceTest;

class Employee {
 float salary= 260000;
}

public class Programmer extends Employee{
	
	int bonus= 100000;
	public static void main(String[] args) {
		Programmer p1= new Programmer();
		
		System.out.println("Programmer salary is:" +p1.salary);
		System.out.println("Programmer bonus is:" +p1.bonus);
	}
}


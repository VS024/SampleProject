package studentComparatorTest;

import java.util.Comparator;

public class AgeComparator2 implements Comparator<Student4>{

	@Override
	public int compare(Student4 std41, Student4 std42) {
		if(std41.age == std42.age)
			return 0;
		
		else if(std41.age >= std42.age)
			
			return 1;
		else return -1;
	}

}

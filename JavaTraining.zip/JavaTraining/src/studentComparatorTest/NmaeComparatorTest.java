package studentComparatorTest;

import java.util.Comparator;

public class NmaeComparatorTest implements Comparator<Student4>{

	public int compare(Student4 std41, Student4 std42) {
		return std41.name.compareTo(std42.name);
	}
}

package studentComparatorTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class StudentComparatorTest {

	public static void main(String[] args) {
		
		List<Student4> stdList= new ArrayList<>();
		
		stdList.add(new Student4(101,"Vijay",23));  
		stdList.add(new Student4(106,"Ajay",27));  
		stdList.add(new Student4(105,"Jai",21));
		
		System.out.println("Sorting by name");
		
		Collections.sort(stdList, new NmaeComparatorTest());
		for(Student4 std4: stdList) {
			System.out.println(std4.rollNo+ " " + std4.name + " " + std4.age);
		}
		System.out.println("Sorting by rollno");
		Collections.sort(stdList, new RollnoComparatorTest());
		for(Student4 std4: stdList) {
			System.out.println(std4.rollNo+ " " + std4.name + " " + std4.age);
		}
		System.out.println("Sorting by age");
		Collections.sort(stdList, new AgeComparator2());
		for(Student4 std4: stdList) {
			System.out.println(std4.rollNo+ " " + std4.name + " " + std4.age);
		}
	}
}

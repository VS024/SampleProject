package studentComparatorTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Student6{
	int rollno;
	String name;
	int age;
	public Student6(int rollno, String name, int age) {
		this.rollno = rollno;
		this.name = name;
		this.age = age;
	}
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
}
public class ComparatorJava8Test {

	public static void main(String[] args) {
		List<Student6> stdList= new ArrayList<>();
		
		stdList.add(new Student6(101,"Vijay",23));  
		stdList.add(new Student6(106,"Ajay",27));  
		stdList.add(new Student6(105,"Jai",21));
		stdList.add(new Student6(103,null,26));
		
		//Comparator<Student6> cmp1= Comparator.comparing(Student6:: getRollno);
		
		Comparator<Student6> cmp5 = Comparator.comparing(Student6::getAge);
		Collections.sort(stdList, cmp5);
		stdList.stream().forEach(list-> System.out.println(list.age+ " : age"+" "+ list.name+ ": name"));
//		Collections.sort(stdList, cmp1);
//		
//		
//		
//		for(Student6 std: stdList) {
//			System.out.println(std.rollno+ " " + std.name + " " + std.age);
//		}
//		Comparator<Student6> cmp2= Comparator.comparing(Student6::getName);
//		Comparator<Student6> cmp4= Comparator.comparing(Student6::getName, Comparator.nullsFirst(String::compareTo));
//		//Comparator<Student6> cmp5= Comparator.comparing(Student6::getName, Comparator.nullsLast(String::compareTo));
//	//	Collections.sort(stdList, cmp2);
//		Collections.sort(stdList, cmp4);
//		for(Student6 std: stdList) {
//			System.out.println(std.rollno+ " " + std.name + " " + std.age);
//		}
//		
//		Comparator<Student6> cmp3 = Comparator.comparing(Student6:: getAge);
//		Collections.sort(stdList, cmp3);
//		for(Student6 std: stdList) {
//			System.out.println(std.rollno+ " " + std.name + " " + std.age);
//		}
		
	}
}

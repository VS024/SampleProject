package studentComparatorTest;

import java.util.Comparator;

public class RollnoComparatorTest implements Comparator<Student4>{

	public int compare(Student4 s1, Student4 s2) {
		
		if(s1.rollNo == s2.rollNo)
			return 0;
		else if(s1.rollNo> s2.rollNo)
			return 1;
		else return -1;
	}
}

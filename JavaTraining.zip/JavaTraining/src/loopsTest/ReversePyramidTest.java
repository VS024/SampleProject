package loopsTest;

public class ReversePyramidTest {
	
	public static void main(String[] args) {
		
		ReversePyramidTest rpt= new ReversePyramidTest();
		rpt.reversePyramid();
		int term=5;
		for(int i=1; i<=term; i++) {
			
			for(int j=term; j>=i; j--) {
				System.out.print("* ");
			}
			System.out.println();
		}
	}
	
	public void reversePyramid() {
		int term=6;  
		for(int i=1;i<=term;i++){  
		for(int j=term;j>=i;j--){  
		        System.out.print("* ");  
		}  
		System.out.println();//new line  
		}  
	}

}

package loopsTest;

public class SimpleTest {

	public static void main(String[] args) {
		
		int i =5;
		
		for(int j=0; j<i; j++) {
			//System.out.println(j);
			for(int k =0; k<j; k++)
			System.out.println(j + " " +k);
		}
	}
}

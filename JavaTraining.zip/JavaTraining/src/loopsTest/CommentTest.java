package loopsTest;

public class CommentTest {

	public static void main(String[] args) {
		//print the comment
		//\u000d System.out.println("Printing comment");
	}
}

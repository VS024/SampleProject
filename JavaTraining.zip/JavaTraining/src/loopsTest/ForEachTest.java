package loopsTest;

public class ForEachTest {
	
	public static void main(String[] args) {
		int intArray[]= {10, 11, 25,28,32,44};
		
		for(int arr: intArray) {
			System.out.println(arr);
		}
	}

}

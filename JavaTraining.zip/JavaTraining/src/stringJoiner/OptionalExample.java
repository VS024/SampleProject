package stringJoiner;

import java.util.Optional;

public class OptionalExample {

	public static void main(String[] args) {
		String[] str= new String[10];
		Integer[] intNum= new Integer[6];
		
		Optional<String> checkNull = Optional.ofNullable(str[5]);
		Optional<Integer> checkIntNull= Optional.ofNullable(intNum[4]);
		System.out.println(checkNull);
		System.out.println(checkIntNull);
		
//		if(checkNull.isPresent()) {
//			String lowercaseString = str[5].toLowerCase(); 
//			System.out.print(lowercaseString);  
//        }else  
//            System.out.println("string value is not present");
	}
}

package stringJoiner;

import java.util.StringJoiner;

public class StringJoinerExample {

	public static void main(String[] args) {
		//StringJoiner joinNames= new StringJoiner(",");
		StringJoiner joinNames= new StringJoiner(",", "[", "]");//passing comma(,) and square-brackets as delimiter
		
		joinNames.add("Radha");
		joinNames.add("Rekha");
		joinNames.add("Laxmi");
		System.out.println(joinNames);
	}
}
